'use strict';
// Run from a shell with MAXREC_FFMPEG set to the absolute path to FFmpeg.
const assert = require('node:assert/strict');
const fs = require('node:fs'), os = require('node:os'), path = require('node:path');
const { spawn, spawnSync } = require('node:child_process');
const core = require('../payload/app/core');
const work = fs.mkdtempSync(path.join(os.tmpdir(), 'maxrec-smoke-'));
const helper = path.join(work, 'audio-fixture.js');
const data = path.join(work, 'data'), out = path.join(work, 'test recordings');
const ffmpeg = process.env.MAXREC_FFMPEG;
assert.ok(path.isAbsolute(ffmpeg || ''), 'Set MAXREC_FFMPEG to a recent FFmpeg binary');
fs.writeFileSync(helper, `const kind = process.argv[2]; if (kind === 'list') console.log(JSON.stringify({render:[],capture:[]})); else if (kind === 'capture') {console.error('READY fixture'); const b=Buffer.alloc(480*8); for(let i=0;i<480;i++){const n=0.1*Math.sin(i*Math.PI*2/120);b.writeFloatLE(n,i*8);b.writeFloatLE(n,i*8+4);}setInterval(()=>process.stdout.write(b),10);} else if (kind === 'hotkey') {console.error('READY');process.stdin.resume();}`);
const def = core.defaults(out);
const quality = {bitrate:8,mode:'vbr',cq:20,quality:'balanced',fps:30};
for (const opt of ['spatial-aq', 'spatial_aq', '']) {
  const help = opt ? `Encoder h264_nvenc
  -${opt}    <boolean>    E..V....... Enable Spatial AQ
` : 'No option here';
  assert.equal(core.nvencSpatialOption(help), opt);
  for(const stream of [0, 1]) {
    const args=core.encArgs('nvenc','h264',quality,stream,{nvencSpatial:{h264:opt}});
    assert.deepEqual(args.filter(a=>a.startsWith('-spatial')),opt ? [`-${opt}:v:${stream}`] : []);
    assert.ok(args.includes(`-profile:v:${stream}`));
  }
}
const geo=core.geometry(def,{w:1280,h:720});
const mainArgs=core.buildMain({s:def,enc:'cpu',codec:'h264',geo,variant:'sw',monIdx:0,audio:[{port:1234,name:'Mic',gain:0}],out:'screen.mkv'});
const camArgs=core.buildCam({s:def,enc:'cpu',mic:{port:4321},camInput:core.camInput({...def.webcam,device:'Web Camera'}),out:'cam.mkv'});
assert.ok(mainArgs.includes('tcp://127.0.0.1:1234') && camArgs.includes('tcp://127.0.0.1:4321'));
assert.ok(!mainArgs.includes('-thread_queue_size') && !camArgs.includes('-thread_queue_size'));
assert.ok(camArgs.includes('-profile:v:0') && !camArgs.includes('-profile'));
// Check NVENC CLI option parsing even on a machine without a GPU.
const supported = spawnSync(ffmpeg,['-hide_banner','-h','encoder=h264_nvenc'],{encoding:'utf8',timeout:10000});
const aq = core.nvencSpatialOption((supported.stdout||'')+'\n'+(supported.stderr||''));
if(aq){
  const run=spawnSync(ffmpeg,['-hide_banner','-loglevel','warning','-f','lavfi','-i','color=c=black:s=1280x720:r=30','-frames:v','1',...core.encArgs('nvenc','h264',quality,0,{nvencSpatial:{h264:aq}}),'-f','null','-'],{encoding:'utf8',timeout:10000});
  assert.ifError(run.error);
  assert.doesNotMatch(run.stderr,/Unrecognized option|Option not found|Error splitting the argument list|profile is ambiguous/i);
}

const checked = core.sanitize({video:null, audio:{tracks:[null, {id:'same'}, {id:'same'}, {id:'__proto__'}]}, output:[]}, def);
assert.equal(checked.video.fps, def.video.fps);
assert.equal(checked.output.folder, def.output.folder);
assert.equal(new Set(checked.audio.tracks.map(t=>t.id)).size, 3);
assert.ok(checked.audio.tracks.every(t=>t.id !== '__proto__'));
const feeder = new core.Feeder('test'); feeder.go(process.hrtime.bigint(), 0); feeder.finish(); feeder.go(process.hrtime.bigint(), 0); assert.equal(feeder.delay, 1440); feeder.finish();
const {MAXREC_PORT: _port, ...env} = process.env;
const child = spawn(process.execPath, [path.join(__dirname, '../payload/app/server.js')], { env: { ...env, MAXREC_TEST:'1', MAXREC_NO_UI:'1', MAXREC_KEEP:'1', MAXREC_DATA:data, MAXREC_HELPER:helper, MAXREC_TEST_SRC:'testsrc2=size=320x180:rate=30', MAXREC_TEST_CAM:'testsrc2=size=320x180:rate=30' }, stdio:['ignore','pipe','pipe'] });
let logs = ''; child.stdout.on('data', d=>logs+=d); child.stderr.on('data', d=>logs+=d);
let base;
const wait = ms => new Promise(r=>setTimeout(r,ms));
async function until(fn, label) { for(let i=0;i<180;i++){if(child.exitCode!==null) throw new Error('server exited');const v=await fn();if(v) return v; await wait(150);} throw new Error('Timeout: '+label); }
async function call(route, body) { const r=await fetch(base+'/api/'+route,body===undefined?{}:{method:'POST',headers:{'X-MaxRec':'1','Content-Type':'application/json'},body:JSON.stringify(body)});assert.ok(r.ok,route+' '+r.status);return r.json(); }
const state = () => call('state');
function checkFile(f, format) {
  assert.ok(fs.statSync(f.path).size>0);
  const r=spawnSync(ffmpeg, ['-hide_banner','-i',f.path,'-f','null','-'], {encoding:'utf8',timeout:10000});
  assert.equal(r.status, 0, r.stderr);
  assert.match(r.stderr, format);
  return r.stderr;
}
(async()=>{
  try {
    const port=await until(()=>{try{return JSON.parse(fs.readFileSync(path.join(data,'instance.json'))).port;}catch{}},'startup');
    base='http://127.0.0.1:'+port;
    await until(async()=>{const s=await state();return s.caps.probed && s.dev.monitors.length;},'discovery');
    assert.equal((await fetch(base+'/')).status,200);
    const shot=await call('snapshot',{kind:'screen'});
    const image=await fetch(base+shot.url); assert.equal(image.status,200);
    assert.equal(image.headers.get('content-type'),'image/jpeg'); assert.ok((await image.arrayBuffer()).byteLength>100);
    const events=await fetch(base+'/api/events');
    const stream=events.body.getReader(); assert.match(new TextDecoder().decode((await stream.read()).value), /retry:|event: state/); await stream.cancel();
    assert.equal((await fetch(base+'/api/rec')).status,405);
    assert.equal((await fetch(base+'/api/rec',{method:'POST'})).status,403);
    await call('settings',{patch:{video:{fps:30,encoder:'cpu'},audio:{wav:true,codec:'flac',tracks:[{id:'a',name:'Same',on:true,type:'system'},{id:'b',name:'same',on:true,type:'mic'}]},webcam:{mode:'file',mic:true},output:{folder:out}}});
    await call('rec',{action:'start'});
    await until(async()=>{const s=await state(); if(s.rec.error) throw Error(s.rec.error); return s.rec.state==='recording';},'recording');
    await call('settings',{patch:{output:{container:'mkv'},audio:{wav:false,tracks:[]},webcam:{mode:'off'}}});
    await call('monitor',{on:true});
    await call('rec',{action:'stop'});
    const first=await until(async()=>{const s=await state();return s.rec.state==='idle' && s.rec;},'save');
    assert.doesNotMatch(fs.readFileSync(path.join(data,'logs','ffmpeg-last.log'),'utf8'),/thread_queue_size|profile is ambiguous|Unrecognized option/i);
    assert.equal(first.error,''); assert.equal(first.files.length,4,JSON.stringify(first));
    for(const f of first.files){ if(f.kind==='audio'){assert.match(f.path,/\.wav$/);checkFile(f,/pcm_s24le/);} else {assert.match(f.path,/\.mp4$/);const report=checkFile(f,/Video: h264/); assert.match(report,/Audio: aac/);} }
    assert.equal(new Set(first.files.map(f=>f.path.toLowerCase())).size,4);
    await call('rec',{action:'start'});
    await until(async()=>{const s=await state();if(s.rec.error) throw Error(s.rec.error);return s.rec.state==='recording';},'second recording');
    await call('rec',{action:'stop'});
    await call('quit',{});
    await new Promise((resolve,reject)=>{const t=setTimeout(()=>reject(Error('shutdown timeout')),25000);child.once('exit',code=>{clearTimeout(t);code===0?resolve():reject(Error('Exit '+code));});});
    const attempts=fs.readdirSync(out).map(d=>path.join(out,d));
    assert.equal(attempts.length,2);
    const second=attempts.find(p=>p!==path.dirname(first.files[0].path));
    checkFile({path:path.join(second,'Screen.mkv')},/Video: h264/);
    console.log('PASS: settings, local API, FFmpeg recording, separate webcam, audio files, MP4/AAC, recording settings snapshot, MKV, graceful shutdown');
  } catch(e) { console.error(logs); try {console.error(fs.readFileSync(path.join(data,'logs','ffmpeg-last.log'),'utf8'));}catch{} throw e; }
  finally { if(child.exitCode===null) child.kill(); fs.rmSync(work,{recursive:true,force:true}); }
})().catch(e=>{console.error(e);process.exitCode=1;});
