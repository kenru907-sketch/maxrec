// MaxRec helper: захват звука через WASAPI (система / микрофон / отдельное приложение) и глобальные горячие клавиши.
// C# 5, .NET Framework 4.x. Сборка: csc /unsafe maxhelper.cs
using System;
using System.IO;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading;

namespace MaxRec
{
    // ---------------- COM ----------------
    [ComImport, Guid("BCDE0395-E52F-467C-8E3D-C4579291692E")]
    class MMDeviceEnumeratorCoClass { }

    [ComImport, Guid("A95664D2-9614-4F35-A746-DE8DB63617E6"), InterfaceType(ComInterfaceType.InterfaceIsIUnknown)]
    interface IMMDeviceEnumerator
    {
        [PreserveSig] int EnumAudioEndpoints(int dataFlow, int dwStateMask, out IMMDeviceCollection ppDevices);
        [PreserveSig] int GetDefaultAudioEndpoint(int dataFlow, int role, out IMMDevice ppEndpoint);
        [PreserveSig] int GetDevice([MarshalAs(UnmanagedType.LPWStr)] string pwstrId, out IMMDevice ppDevice);
        [PreserveSig] int RegisterEndpointNotificationCallback(IntPtr pClient);
        [PreserveSig] int UnregisterEndpointNotificationCallback(IntPtr pClient);
    }

    [ComImport, Guid("0BD7A1BE-7A1A-44DB-8397-CC5392387B5E"), InterfaceType(ComInterfaceType.InterfaceIsIUnknown)]
    interface IMMDeviceCollection
    {
        [PreserveSig] int GetCount(out uint pcDevices);
        [PreserveSig] int Item(uint nDevice, out IMMDevice ppDevice);
    }

    [ComImport, Guid("D666063F-1587-4E43-81F1-B948E807363F"), InterfaceType(ComInterfaceType.InterfaceIsIUnknown)]
    interface IMMDevice
    {
        [PreserveSig] int Activate(ref Guid iid, int dwClsCtx, IntPtr pActivationParams, [MarshalAs(UnmanagedType.IUnknown)] out object ppInterface);
        [PreserveSig] int OpenPropertyStore(int stgmAccess, out IPropertyStore ppProperties);
        [PreserveSig] int GetId([MarshalAs(UnmanagedType.LPWStr)] out string ppstrId);
        [PreserveSig] int GetState(out int pdwState);
    }

    [StructLayout(LayoutKind.Sequential)]
    struct PROPERTYKEY { public Guid fmtid; public uint pid; }

    [StructLayout(LayoutKind.Sequential)]
    struct PROPVARIANT { public ushort vt; public ushort r1; public ushort r2; public ushort r3; public IntPtr p; public IntPtr p2; }

    [ComImport, Guid("886D8EEB-8CF2-4446-8D02-CDBA1DBDCF99"), InterfaceType(ComInterfaceType.InterfaceIsIUnknown)]
    interface IPropertyStore
    {
        [PreserveSig] int GetCount(out uint cProps);
        [PreserveSig] int GetAt(uint iProp, out PROPERTYKEY pkey);
        [PreserveSig] int GetValue(ref PROPERTYKEY key, out PROPVARIANT pv);
        [PreserveSig] int SetValue(ref PROPERTYKEY key, ref PROPVARIANT pv);
        [PreserveSig] int Commit();
    }

    [ComImport, Guid("1CB9AD4C-DBFA-4C32-B178-C2F568A703B2"), InterfaceType(ComInterfaceType.InterfaceIsIUnknown)]
    interface IAudioClient
    {
        [PreserveSig] int Initialize(int shareMode, int streamFlags, long hnsBufferDuration, long hnsPeriodicity, IntPtr pFormat, ref Guid audioSessionGuid);
        [PreserveSig] int GetBufferSize(out uint pNumBufferFrames);
        [PreserveSig] int GetStreamLatency(out long phnsLatency);
        [PreserveSig] int GetCurrentPadding(out uint pNumPaddingFrames);
        [PreserveSig] int IsFormatSupported(int shareMode, IntPtr pFormat, out IntPtr ppClosestMatch);
        [PreserveSig] int GetMixFormat(out IntPtr ppDeviceFormat);
        [PreserveSig] int GetDevicePeriod(out long phnsDefaultDevicePeriod, out long phnsMinimumDevicePeriod);
        [PreserveSig] int Start();
        [PreserveSig] int Stop();
        [PreserveSig] int Reset();
        [PreserveSig] int SetEventHandle(IntPtr eventHandle);
        [PreserveSig] int GetService(ref Guid riid, [MarshalAs(UnmanagedType.IUnknown)] out object ppv);
    }

    [ComImport, Guid("C8ADBD64-E71E-48A0-A4DE-185C395CD317"), InterfaceType(ComInterfaceType.InterfaceIsIUnknown)]
    interface IAudioCaptureClient
    {
        [PreserveSig] int GetBuffer(out IntPtr ppData, out uint pNumFramesToRead, out uint pdwFlags, out ulong pu64DevicePosition, out ulong pu64QPCPosition);
        [PreserveSig] int ReleaseBuffer(uint numFramesRead);
        [PreserveSig] int GetNextPacketSize(out uint pNumFramesInNextPacket);
    }

    [ComImport, Guid("72A22D78-CDE4-431D-B8CC-843A71199B6D"), InterfaceType(ComInterfaceType.InterfaceIsIUnknown)]
    interface IActivateAudioInterfaceAsyncOperation
    {
        [PreserveSig] int GetActivateResult(out int activateResult, [MarshalAs(UnmanagedType.IUnknown)] out object activatedInterface);
    }

    [ComImport, Guid("41D949AB-9862-444A-80F6-C261334DA5EB"), InterfaceType(ComInterfaceType.InterfaceIsIUnknown)]
    interface IActivateAudioInterfaceCompletionHandler
    {
        [PreserveSig] int ActivateCompleted(IActivateAudioInterfaceAsyncOperation activateOperation);
    }

    [ComImport, Guid("94EA2B94-E9CC-49E0-C0FF-EE64CA8F5B90"), InterfaceType(ComInterfaceType.InterfaceIsIUnknown)]
    interface IAgileObject { }

    class ActivationHandler : IActivateAudioInterfaceCompletionHandler, IAgileObject
    {
        public ManualResetEvent Done = new ManualResetEvent(false);
        public int ActivateCompleted(IActivateAudioInterfaceAsyncOperation activateOperation) { Done.Set(); return 0; }
    }

    [StructLayout(LayoutKind.Sequential)]
    struct MSG { public IntPtr hwnd; public uint message; public IntPtr wParam; public IntPtr lParam; public uint time; public int ptX; public int ptY; }

    static class Native
    {
        [DllImport("Mmdevapi.dll", ExactSpelling = true, PreserveSig = false)]
        public static extern void ActivateAudioInterfaceAsync(
            [MarshalAs(UnmanagedType.LPWStr)] string deviceInterfacePath,
            [MarshalAs(UnmanagedType.LPStruct)] Guid riid,
            IntPtr activationParams,
            IActivateAudioInterfaceCompletionHandler completionHandler,
            out IActivateAudioInterfaceAsyncOperation activationOperation);

        [DllImport("ole32.dll")] public static extern int PropVariantClear(ref PROPVARIANT pvar);
        [DllImport("user32.dll")] public static extern bool RegisterHotKey(IntPtr hWnd, int id, uint fsModifiers, uint vk);
        [DllImport("user32.dll")] public static extern int GetMessage(out MSG lpMsg, IntPtr hWnd, uint wMsgFilterMin, uint wMsgFilterMax);
    }

    // ---------------- формат и конвертер ----------------
    class FormatInfo { public int Channels; public int Rate; public int Bits; public bool IsFloat; }

    class Source
    {
        public IAudioClient Client; public IAudioCaptureClient Cap; public FormatInfo Fmt; public AutoResetEvent Evt; public string Desc;
    }

    unsafe class Converter
    {
        FormatInfo f; float prevL, prevR; double pos; float[] src = new float[0]; float[] dst = new float[0];
        public Converter(FormatInfo fi) { f = fi; }
        bool Fast() { return f.IsFloat && f.Bits == 32 && f.Channels == 2 && f.Rate == 48000; }

        public int Process(IntPtr data, int frames, bool silent, ref byte[] buf)
        {
            int ch = f.Channels;
            if (Fast())
            {
                int bytes = frames * 8;
                if (buf.Length < bytes) buf = new byte[bytes * 2];
                if (silent) Array.Clear(buf, 0, bytes); else Marshal.Copy(data, buf, 0, bytes);
                return bytes;
            }
            int n = frames * ch;
            if (src.Length < n) src = new float[n * 2];
            if (silent) Array.Clear(src, 0, n);
            else if (f.IsFloat && f.Bits == 32) { float* p = (float*)data; for (int i = 0; i < n; i++) src[i] = p[i]; }
            else if (!f.IsFloat && f.Bits == 16) { short* p = (short*)data; for (int i = 0; i < n; i++) src[i] = p[i] / 32768f; }
            else if (!f.IsFloat && f.Bits == 32) { int* p = (int*)data; for (int i = 0; i < n; i++) src[i] = p[i] / 2147483648f; }
            else if (!f.IsFloat && f.Bits == 24)
            {
                byte* p = (byte*)data;
                for (int i = 0; i < n; i++) { int v = (p[i * 3] << 8) | (p[i * 3 + 1] << 16) | (p[i * 3 + 2] << 24); src[i] = v / 2147483648f; }
            }
            else Array.Clear(src, 0, n);

            double step = f.Rate / 48000.0;
            int maxOut = (int)(frames / step) + 8;
            if (dst.Length < maxOut * 2) dst = new float[maxOut * 4];
            int o = 0;
            for (int i = 0; i < frames; i++)
            {
                float l, r; int b = i * ch;
                if (ch == 1) { l = src[b]; r = l; }
                else if (ch == 2) { l = src[b]; r = src[b + 1]; }
                else if (ch == 4) { l = (src[b] + 0.5f * src[b + 2]) * 0.8f; r = (src[b + 1] + 0.5f * src[b + 3]) * 0.8f; }
                else
                {
                    float fc = src[b + 2] * 0.707f;
                    float bl = ch > 4 ? src[b + 4] : 0f; float br = ch > 5 ? src[b + 5] : 0f;
                    float sl = ch > 6 ? src[b + 6] : 0f; float sr = ch > 7 ? src[b + 7] : 0f;
                    l = (src[b] + fc + 0.6f * (bl + sl)) * 0.7f; r = (src[b + 1] + fc + 0.6f * (br + sr)) * 0.7f;
                }
                if (f.Rate == 48000) { dst[o++] = l; dst[o++] = r; continue; }
                while (pos < 1.0 && o + 2 <= dst.Length)
                {
                    dst[o++] = prevL + (l - prevL) * (float)pos;
                    dst[o++] = prevR + (r - prevR) * (float)pos;
                    pos += step;
                }
                pos -= 1.0; prevL = l; prevR = r;
            }
            int bytes2 = o * 4;
            if (buf.Length < bytes2) buf = new byte[bytes2 * 2];
            Buffer.BlockCopy(dst, 0, buf, 0, bytes2);
            return bytes2;
        }
    }

    // ---------------- открытие источников ----------------
    static class Audio
    {
        static readonly Guid IID_IAudioClient = new Guid("1CB9AD4C-DBFA-4C32-B178-C2F568A703B2");
        static readonly Guid IID_IAudioCaptureClient = new Guid("C8ADBD64-E71E-48A0-A4DE-185C395CD317");
        const int LOOPBACK = 0x00020000;
        const int EVENTCB = 0x00040000;
        const int SRCQ = 0x08000000;
        const int AUTOCONVERT = unchecked((int)0x80000000);

        static IntPtr MakeFormat(bool isFloat, int channels, int rate, int bits)
        {
            IntPtr p = Marshal.AllocHGlobal(18);
            int align = channels * bits / 8;
            Marshal.WriteInt16(p, 0, (short)(isFloat ? 3 : 1));
            Marshal.WriteInt16(p, 2, (short)channels);
            Marshal.WriteInt32(p, 4, rate);
            Marshal.WriteInt32(p, 8, rate * align);
            Marshal.WriteInt16(p, 12, (short)align);
            Marshal.WriteInt16(p, 14, (short)bits);
            Marshal.WriteInt16(p, 16, 0);
            return p;
        }

        static FormatInfo ReadFormat(IntPtr p)
        {
            FormatInfo f = new FormatInfo();
            int tag = Marshal.ReadInt16(p, 0) & 0xFFFF;
            f.Channels = Marshal.ReadInt16(p, 2) & 0xFFFF;
            f.Rate = Marshal.ReadInt32(p, 4);
            f.Bits = Marshal.ReadInt16(p, 14) & 0xFFFF;
            f.IsFloat = (tag == 3);
            if (tag == 0xFFFE && Marshal.ReadInt16(p, 16) >= 22) f.IsFloat = (Marshal.ReadInt32(p, 24) == 3);
            return f;
        }

        static IAudioClient ActivateProcessLoopback(uint pid, bool exclude)
        {
            IntPtr blob = Marshal.AllocHGlobal(12);
            Marshal.WriteInt32(blob, 0, 1);
            Marshal.WriteInt32(blob, 4, (int)pid);
            Marshal.WriteInt32(blob, 8, exclude ? 1 : 0);
            int pvSize = 8 + 2 * IntPtr.Size;
            IntPtr pv = Marshal.AllocHGlobal(pvSize);
            for (int i = 0; i < pvSize; i++) Marshal.WriteByte(pv, i, 0);
            Marshal.WriteInt16(pv, 0, 65);
            Marshal.WriteInt32(pv, 8, 12);
            Marshal.WriteIntPtr(pv, 8 + IntPtr.Size, blob);
            try
            {
                ActivationHandler h = new ActivationHandler();
                IActivateAudioInterfaceAsyncOperation op;
                Native.ActivateAudioInterfaceAsync("VAD\\Process_Loopback", IID_IAudioClient, pv, h, out op);
                if (!h.Done.WaitOne(8000)) throw new Exception("activation timeout");
                int hr; object o;
                int r = op.GetActivateResult(out hr, out o);
                if (r != 0 || hr != 0 || o == null) throw new Exception("activation failed 0x" + (r != 0 ? r : hr).ToString("X8"));
                return (IAudioClient)o;
            }
            finally { Marshal.FreeHGlobal(pv); Marshal.FreeHGlobal(blob); }
        }

        static Source Finish(IAudioClient c, FormatInfo fi, string desc)
        {
            Source s = new Source(); s.Client = c; s.Fmt = fi; s.Desc = desc;
            s.Evt = new AutoResetEvent(false);
            int hr = c.SetEventHandle(s.Evt.SafeWaitHandle.DangerousGetHandle());
            if (hr != 0) throw new Exception("SetEventHandle 0x" + hr.ToString("X8"));
            Guid gid = IID_IAudioCaptureClient; object o;
            hr = c.GetService(ref gid, out o);
            if (hr != 0 || o == null) throw new Exception("GetService 0x" + hr.ToString("X8"));
            s.Cap = (IAudioCaptureClient)o;
            hr = c.Start();
            if (hr != 0) throw new Exception("Start 0x" + hr.ToString("X8"));
            return s;
        }

        static Source OpenProcess(uint pid, bool exclude)
        {
            object[][] tries = new object[][] {
                new object[] { true, 32, 48000, 0 },
                new object[] { true, 32, 48000, AUTOCONVERT | SRCQ },
                new object[] { false, 16, 48000, 0 },
                new object[] { false, 16, 44100, 0 } };
            string lastErr = "";
            foreach (object[] t in tries)
            {
                IntPtr fmt = IntPtr.Zero;
                try
                {
                    IAudioClient c = ActivateProcessLoopback(pid, exclude);
                    fmt = MakeFormat((bool)t[0], 2, (int)t[2], (int)t[1]);
                    Guid g = Guid.Empty;
                    int flags = LOOPBACK | EVENTCB | (int)t[3];
                    int hr = c.Initialize(0, flags, 2000000L, 0L, fmt, ref g);
                    if (hr != 0) { lastErr = "init 0x" + hr.ToString("X8"); continue; }
                    FormatInfo fi = ReadFormat(fmt);
                    return Finish(c, fi, "process " + pid + (exclude ? " (exclude) " : " ") + fi.Rate + "Hz");
                }
                catch (Exception ex) { lastErr = ex.Message; }
                finally { if (fmt != IntPtr.Zero) Marshal.FreeHGlobal(fmt); }
            }
            throw new Exception("process loopback unavailable: " + lastErr);
        }

        static IMMDevice GetDev(IMMDeviceEnumerator en, int flow, string id)
        {
            IMMDevice d;
            int hr;
            if (string.IsNullOrEmpty(id)) hr = en.GetDefaultAudioEndpoint(flow, 0, out d); else hr = en.GetDevice(id, out d);
            if (hr != 0 || d == null) throw new Exception("device not found 0x" + hr.ToString("X8"));
            return d;
        }

        static IAudioClient ActivateDevice(IMMDevice d)
        {
            Guid iid = IID_IAudioClient; object o;
            int hr = d.Activate(ref iid, 23, IntPtr.Zero, out o);
            if (hr != 0 || o == null) throw new Exception("activate failed 0x" + hr.ToString("X8"));
            return (IAudioClient)o;
        }

        static Source OpenDevice(int flow, string id)
        {
            IMMDeviceEnumerator en = (IMMDeviceEnumerator)new MMDeviceEnumeratorCoClass();
            IMMDevice dev = GetDev(en, flow, id);
            int baseFlags = (flow == 0 ? LOOPBACK : 0) | EVENTCB;
            string what = flow == 0 ? "loopback " : "mic ";
            Guid g = Guid.Empty;
            IntPtr fmt = MakeFormat(true, 2, 48000, 32);
            try
            {
                IAudioClient c = ActivateDevice(dev);
                int hr = c.Initialize(0, baseFlags | AUTOCONVERT | SRCQ, 2000000L, 0L, fmt, ref g);
                if (hr == 0) return Finish(c, ReadFormat(fmt), what + "48000Hz float");
            }
            catch (Exception) { }
            finally { Marshal.FreeHGlobal(fmt); }

            IAudioClient c2 = ActivateDevice(dev);
            IntPtr mix;
            int hr2 = c2.GetMixFormat(out mix);
            if (hr2 != 0 || mix == IntPtr.Zero) throw new Exception("GetMixFormat 0x" + hr2.ToString("X8"));
            FormatInfo fi = ReadFormat(mix);
            hr2 = c2.Initialize(0, baseFlags, 2000000L, 0L, mix, ref g);
            Marshal.FreeCoTaskMem(mix);
            if (hr2 != 0) throw new Exception("Initialize 0x" + hr2.ToString("X8"));
            return Finish(c2, fi, what + fi.Rate + "Hz " + fi.Channels + "ch");
        }

        public static Source Open(string kind, string device, uint pid)
        {
            if (kind == "app" || kind == "except") return OpenProcess(pid, kind == "except");
            return OpenDevice(kind == "mic" ? 1 : 0, device);
        }
    }

    // ---------------- команды ----------------
    static class ListCmd
    {
        static string J(string s)
        {
            StringBuilder b = new StringBuilder("\"");
            foreach (char c in s)
            {
                if (c == '"') b.Append("\\\""); else if (c == '\\') b.Append("\\\\"); else if (c < 32) b.Append(' '); else b.Append(c);
            }
            b.Append('"');
            return b.ToString();
        }

        static string Friendly(IMMDevice d)
        {
            try
            {
                IPropertyStore ps;
                if (d.OpenPropertyStore(0, out ps) != 0 || ps == null) return "";
                PROPERTYKEY key = new PROPERTYKEY();
                key.fmtid = new Guid("a45c254e-df1c-4efd-8020-67d146a850e0"); key.pid = 14;
                PROPVARIANT pv;
                string name = "";
                if (ps.GetValue(ref key, out pv) == 0)
                {
                    if (pv.vt == 31 && pv.p != IntPtr.Zero) name = Marshal.PtrToStringUni(pv.p);
                    Native.PropVariantClear(ref pv);
                }
                return name == null ? "" : name;
            }
            catch (Exception) { return ""; }
        }

        static void Flow(StringBuilder sb, IMMDeviceEnumerator en, int flow)
        {
            string defId = "";
            IMMDevice dd;
            if (en.GetDefaultAudioEndpoint(flow, 0, out dd) == 0 && dd != null) { string tmp; if (dd.GetId(out tmp) == 0) defId = tmp; }
            sb.Append("[");
            IMMDeviceCollection col;
            if (en.EnumAudioEndpoints(flow, 1, out col) == 0 && col != null)
            {
                uint n; col.GetCount(out n);
                bool first = true;
                for (uint i = 0; i < n; i++)
                {
                    IMMDevice d;
                    if (col.Item(i, out d) != 0 || d == null) continue;
                    string id; if (d.GetId(out id) != 0) continue;
                    if (!first) sb.Append(",");
                    first = false;
                    sb.Append("{\"id\":" + J(id) + ",\"name\":" + J(Friendly(d)) + ",\"default\":" + (id == defId ? "true" : "false") + "}");
                }
            }
            sb.Append("]");
        }

        public static int Run()
        {
            IMMDeviceEnumerator en = (IMMDeviceEnumerator)new MMDeviceEnumeratorCoClass();
            StringBuilder sb = new StringBuilder("{\"render\":");
            Flow(sb, en, 0);
            sb.Append(",\"capture\":");
            Flow(sb, en, 1);
            sb.Append("}");
            byte[] bytes = new UTF8Encoding(false).GetBytes(sb.ToString());
            Stream o = Console.OpenStandardOutput();
            o.Write(bytes, 0, bytes.Length); o.Flush();
            return 0;
        }
    }

    static class CaptureCmd
    {
        public static int Run(string[] a)
        {
            string kind = Program.Arg(a, "--kind", "system");
            string dev = Program.Arg(a, "--device", "");
            uint pid; uint.TryParse(Program.Arg(a, "--pid", "0"), out pid);
            Program.WatchParent();
            Source src;
            try { src = Audio.Open(kind, dev, pid); }
            catch (Exception ex) { Console.Error.WriteLine("ERR " + ex.Message.Replace('\r', ' ').Replace('\n', ' ')); return 3; }
            Console.Error.WriteLine("READY " + src.Desc);
            Converter conv = new Converter(src.Fmt);
            Stream stdout = Console.OpenStandardOutput();
            byte[] buf = new byte[65536];
            try
            {
                while (true)
                {
                    src.Evt.WaitOne(20);
                    while (true)
                    {
                        uint next;
                        if (src.Cap.GetNextPacketSize(out next) != 0 || next == 0) break;
                        IntPtr data; uint frames; uint flags; ulong dp; ulong qpc;
                        if (src.Cap.GetBuffer(out data, out frames, out flags, out dp, out qpc) != 0) break;
                        bool silent = (flags & 2) != 0;
                        int n = 0;
                        try { n = conv.Process(data, (int)frames, silent, ref buf); }
                        finally { src.Cap.ReleaseBuffer(frames); }
                        if (n > 0) { stdout.Write(buf, 0, n); stdout.Flush(); }
                    }
                }
            }
            catch (IOException) { return 0; }
            catch (Exception ex) { Console.Error.WriteLine("ERR " + ex.Message.Replace('\r', ' ').Replace('\n', ' ')); return 4; }
        }
    }

    static class HotkeyCmd
    {
        public static int Run(string[] a)
        {
            uint mods; uint vk;
            uint.TryParse(Program.Arg(a, "--mods", "0"), out mods);
            uint.TryParse(Program.Arg(a, "--vk", "120"), out vk);
            Program.WatchParent();
            if (!Native.RegisterHotKey(IntPtr.Zero, 1, mods | 0x4000, vk)) { Console.Error.WriteLine("ERR hotkey is busy"); return 3; }
            Console.Error.WriteLine("READY");
            MSG m;
            while (Native.GetMessage(out m, IntPtr.Zero, 0, 0) > 0)
            {
                if (m.message == 0x0312) { Console.Out.WriteLine("HOTKEY"); Console.Out.Flush(); }
            }
            return 0;
        }
    }

    static class Program
    {
        public static string Arg(string[] a, string name, string def)
        {
            for (int i = 1; i < a.Length - 1; i++) if (a[i] == name) return a[i + 1];
            return def;
        }

        // Когда родительский процесс (Node) закрывает stdin — завершаемся.
        public static void WatchParent()
        {
            Thread t = new Thread(delegate ()
            {
                try { Stream si = Console.OpenStandardInput(); byte[] b = new byte[256]; while (si.Read(b, 0, b.Length) > 0) { } }
                catch (Exception) { }
                Environment.Exit(0);
            });
            t.IsBackground = true;
            t.Start();
        }

        static int Main(string[] args)
        {
            try
            {
                if (args.Length == 0) { Console.Error.WriteLine("usage: maxhelper list | capture | hotkey | version"); return 2; }
                string cmd = args[0].ToLowerInvariant();
                if (cmd == "list") return ListCmd.Run();
                if (cmd == "capture") return CaptureCmd.Run(args);
                if (cmd == "hotkey") return HotkeyCmd.Run(args);
                if (cmd == "version") { Console.WriteLine("maxhelper 1"); return 0; }
            }
            catch (Exception ex) { Console.Error.WriteLine("ERR " + ex.Message.Replace('\r', ' ').Replace('\n', ' ')); return 1; }
            return 2;
        }
    }
}
