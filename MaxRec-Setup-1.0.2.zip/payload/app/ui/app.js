'use strict';
(() => {
  const $ = (s, r) => (r || document).querySelector(s);
  const $$ = (s, r) => Array.from((r || document).querySelectorAll(s));
  function h(tag, props) {
    const e = document.createElement(tag); props = props || {};
    for (const k in props) {
      const v = props[k]; if (v == null || v === false) continue;
      if (k === 'class') e.className = v; else if (k.slice(0, 2) === 'on') e.addEventListener(k.slice(2), v); else if (k === 'html') e.innerHTML = v; else e.setAttribute(k, v === true ? '' : v);
    }
    for (let i = 2; i < arguments.length; i++) {
      const c = arguments[i];
      if (Array.isArray(c)) c.forEach(x => x != null && x !== false && e.append(x.nodeType ? x : document.createTextNode(x)));
      else if (c != null && c !== false) e.append(c.nodeType ? c : document.createTextNode(c));
    }
    return e;
  }
  async function api(p, body) {
    const r = await fetch('/api/' + p, { method: body === undefined ? 'GET' : 'POST', headers: { 'X-MaxRec': '1', 'Content-Type': 'application/json' }, body: body === undefined ? undefined : JSON.stringify(body) });
    return r.json();
  }
  const ENC_L = { nvenc: 'NVIDIA NVENC', amf: 'AMD AMF', qsv: 'Intel QSV', cpu: 'Процессор' }, COD_L = { h264: 'H.264', hevc: 'HEVC', av1: 'AV1' };
  const FMT_L = { mjpeg: 'MJPEG', yuyv422: 'YUY2', nv12: 'NV12', h264: 'H.264', uyvy422: 'UYVY', yuv420p: 'YUV420' };

  let S = null, tab = 'video', camOpts = [], apps = [], tsig = '', lastPatch = 0, pend = {}, pt = null;
  const upd = []; let tupd = []; let REG = fn => { upd.push(fn); fn(); };
  const run = f => { try { f(); } catch (e) { console.error(e); } };
  const sync = () => { upd.forEach(run); tupd.forEach(run); requestAnimationFrame(placePills); };
  const get = p => p.split('.').reduce((o, k) => (o == null ? o : o[k]), S.settings);
  function merge(a, b) {
    if (Array.isArray(b)) return b.map(x => (x && typeof x === 'object') ? merge({}, x) : x);
    if (b && typeof b === 'object') { const o = Object.assign({}, a && typeof a === 'object' && !Array.isArray(a) ? a : {}); for (const k in b) o[k] = merge(o[k], b[k]); return o; }
    return b;
  }
  let saving = Promise.resolve({ ok: true });
  function flushSettings() {
    if (!pt) return saving;
    clearTimeout(pt); pt = null;
    const p = pend; pend = {};
    saving = saving.catch(() => {}).then(() => api('settings', { patch: p })).catch(() => ({ error: 'Нет связи с MaxRec' }));
    return saving;
  }
  async function requestRecording() {
    const result = await flushSettings();
    if (result.error && S && S.rec.state === 'idle') return toast({ kind: 'error', msg: result.error });
    return api('rec', { action: 'toggle' });
  }
  function patch(o) {
    S.settings = merge(S.settings, o); pend = merge(pend, o); lastPatch = Date.now(); clearTimeout(pt);
    pt = setTimeout(flushSettings, 180); sync(); renderStage(); if (o.webcam && 'device' in o.webcam) loadCamOpts();
  }
  const set = (p, v) => { const ks = p.split('.'), o = {}; let c = o; for (let i = 0; i < ks.length - 1; i++) { c[ks[i]] = {}; c = c[ks[i]]; } c[ks[ks.length - 1]] = v; patch(o); };

  /* ---------- элементы управления ---------- */
  function placePills() { $$('.seg').forEach(w => { const p = $('.pill', w), b = $('button.on', w); if (!b || !w.offsetWidth) return; p.style.width = b.offsetWidth + 'px'; p.style.transform = 'translateX(' + b.offsetLeft + 'px)'; p.style.opacity = 1; }); }
  function SegG(getF, setF, optsF) {
    const w = h('div', { class: 'seg' }, h('i', { class: 'pill' })); let sig = '', btns = [];
    REG(() => {
      const o = optsF(), s = JSON.stringify(o);
      if (s !== sig) { sig = s; btns.forEach(b => b.remove()); btns = o.map(x => h('button', { type: 'button', onclick: () => { if (!x[2]) setF(x[0]); } }, x[1])); btns.forEach(b => w.append(b)); }
      const cur = String(getF()); btns.forEach((b, i) => { b.classList.toggle('on', String(o[i][0]) === cur); b.disabled = !!o[i][2]; });
    });
    return w;
  }
  const Seg = (path, optsF) => SegG(() => get(path), v => set(path, v), typeof optsF === 'function' ? optsF : () => optsF);
  function Toggle(path) { const b = h('button', { class: 'tg', role: 'switch', type: 'button', onclick: () => set(path, !get(path)) }, h('i')); REG(() => b.setAttribute('aria-checked', !!get(path))); return b; }
  function Sel(path, optsF, num) {
    const s = h('select', { onchange: () => set(path, num ? Number(s.value) : s.value) });
    REG(() => { const o = optsF(), sig = JSON.stringify(o); if (s.dataset.sig !== sig) { s.dataset.sig = sig; s.innerHTML = ''; o.forEach(x => s.append(h('option', { value: x[0] }, x[1]))); } s.value = String(get(path)); });
    return s;
  }
  function RangeG(getF, setF, min, max, step, fmt) {
    const r = h('input', { type: 'range', min, max, step }), out = h('span', { class: 'val' });
    const paint = () => { const v = Number(r.value); r.style.setProperty('--p', ((v - min) / (max - min) * 100) + '%'); out.textContent = fmt(v); };
    r.addEventListener('input', () => { paint(); setF(Number(r.value)); });
    REG(() => { if (document.activeElement !== r) r.value = getF(); paint(); });
    return h('div', { class: 'rng' }, r, out);
  }
  const Range = (path, min, max, step, fmt) => RangeG(() => get(path), v => set(path, v), min, max, step, fmt);
  function Txt(path, ph) { const i = h('input', { type: 'text', spellcheck: 'false', placeholder: ph || '' }); i.addEventListener('input', () => set(path, i.value)); REG(() => { if (document.activeElement !== i) i.value = get(path) || ''; }); return i; }
  const Row = (label, ctl, hint, id) => { const r = h('div', { class: 'row', id }, h('div', { class: 'lab' }, h('span', {}, label), hint ? h('small', {}, hint) : null), h('div', { class: 'ctl' }, ctl)); return r; };
  const dynHint = (row, fn) => REG(() => { let s = $('small', row); const t = fn(); if (t && !s) { s = h('small'); $('.lab', row).append(s); } if (s) { s.textContent = t || ''; s.hidden = !t; } });
  const Btn = (label, fn, cls) => h('button', { class: 'btn ' + (cls || ''), type: 'button', onclick: fn }, label);

  /* ---------- вычисляемые вещи ---------- */
  const caps = () => (S.caps && S.caps.enc) || {};
  const hasCodec = c => ['nvenc', 'amf', 'qsv', 'cpu'].some(f => caps()[f] && caps()[f][c]);
  function autoEnc() { const E = caps(), c = get('video.codec'), pref = get('video.encoder'); for (const f of pref === 'auto' ? ['nvenc', 'amf', 'qsv', 'cpu'] : [pref, 'cpu']) if (E[f] && E[f][c]) return f; return 'cpu'; }
  function curGeo() { const m = S.dev.monitors.find(x => x.idx === get('video.monitor')) || S.dev.monitors[0] || { w: 1920, h: 1080 }; let w = m.w, hh = m.h; const th = parseInt(get('video.scale'), 10); if (th && th < hh) { w = Math.round(w * th / hh); hh = th; } return { w, h: hh }; }
  const autoBr = () => { const g = curGeo(); return Math.max(8, Math.min(150, Math.round(g.w * g.h * get('video.fps') * 0.32 / 1e6))); };
  const activeTracks = () => S.settings.audio.tracks.filter(t => t.on && ((t.type !== 'app' && t.type !== 'except') || t.exe));
  function SnapBlock(kind) {
    const img = h('img', { class: 'snap', hidden: true, alt: '' });
    const btn = Btn('Снимок', async () => {
      btn.disabled = true; btn.textContent = 'Снимаю…';
      const r = await api('snapshot', { kind, webcam: kind === 'cam' ? S.settings.webcam : undefined });
      btn.disabled = false; btn.textContent = 'Снимок';
      if (r.error) return toast({ kind: 'error', msg: r.error }); img.src = r.url; img.hidden = false;
    });
    return { btn, img };
  }

  /* ---------- страницы ---------- */
  function buildVideo() {
    const p = h('div'), snap = SnapBlock('screen');
    p.append(Row('Экран', [Sel('video.monitor', () => (S.dev.monitors.length ? S.dev.monitors : [{ idx: 0, name: 'Экран 1', w: 1920, h: 1080 }]).map(m => [m.idx, m.name + ' · ' + m.w + '×' + m.h]), true), snap.btn], 'Проверьте кадр кнопкой «Снимок»'));
    p.append(snap.img);
    p.append(Row('Частота кадров', Seg('video.fps', [[30, '30'], [60, '60'], [90, '90'], [120, '120'], [144, '144']])));
    const sc = Row('Размер кадра', Seg('video.scale', [['native', 'Как на экране'], ['1440', '1440p'], ['1080', '1080p'], ['720', '720p']]));
    dynHint(sc, () => get('video.scale') !== 'native' ? 'Масштабирование выполняет процессор — нагрузка выше' : 'Без масштабирования всё делает видеокарта'); p.append(sc);
    const en = Row('Кодер', Sel('video.encoder', () => { const E = caps(), c = get('video.codec'), ok = f => !!(E[f] && E[f][c]); return [['auto', 'Авто'], ['nvenc', 'NVIDIA NVENC' + (ok('nvenc') ? '' : ' — недоступен')], ['amf', 'AMD AMF' + (ok('amf') ? '' : ' — недоступен')], ['qsv', 'Intel QSV' + (ok('qsv') ? '' : ' — недоступен')], ['cpu', 'Процессор (x264)']]; }));
    dynHint(en, () => 'Будет использован: ' + ENC_L[autoEnc()]); p.append(en);
    p.append(Row('Формат видео', Seg('video.codec', () => [['h264', 'H.264'], ['hevc', 'HEVC', !hasCodec('hevc')], ['av1', 'AV1', !hasCodec('av1')]]), 'H.264 открывается везде, HEVC и AV1 — компактнее'));
    p.append(Row('Качество кодера', Seg('video.quality', [['speed', 'Скорость'], ['balanced', 'Баланс'], ['high', 'Высокое'], ['max', 'Максимум']]), 'Выше качество — больше нагрузка на кодер'));
    p.append(Row('Режим', Seg('video.rate', [['vbr', 'Битрейт'], ['cq', 'Постоянное качество']])));
    const br = Row('Битрейт', Range('video.bitrate', 0, 150, 1, v => v ? v + ' Мбит/с' : 'Авто'));
    dynHint(br, () => 'Авто = ' + autoBr() + ' Мбит/с для выбранного размера и частоты кадров'); const cq = Row('Уровень качества', Range('video.cq', 14, 32, 1, v => 'CQ ' + v), 'Меньше число — выше качество и больше файл');
    REG(() => { const m = get('video.rate') === 'cq'; br.hidden = m; cq.hidden = !m; }); p.append(br, cq);
    p.append(Row('Курсор мыши', Toggle('video.cursor')));
    p.append(h('div', { class: 'note' }, 'Экран снимается через Desktop Duplication, кадры остаются в видеопамяти и сразу уходят в аппаратный кодер. Так нагрузка на процессор минимальна.'), h('div', { class: 'note' }, 'Игры в полноэкранном эксклюзивном режиме иногда дают чёрный кадр. Включите в игре режим «Окно без рамки» — картинка не изменится, а запись станет стабильной.'));
    return p;
  }

  function renderTracks() {
    const box = $('#tlist'); if (!box) return; tupd = []; const prev = REG; REG = fn => { tupd.push(fn); fn(); };
    box.innerHTML = ''; S.settings.audio.tracks.forEach((_, i) => box.append(trackRow(i))); REG = prev; tsig = S.settings.audio.tracks.map(t => t.id).join(','); placePills();
  }
  function trackRow(i) {
    const T = () => S.settings.audio.tracks[i] || {};
    const setT = (k, v) => { const arr = S.settings.audio.tracks.map(t => Object.assign({}, t)); if (!arr[i]) return; arr[i][k] = v; patch({ audio: { tracks: arr } }); };
    const on = h('button', { class: 'tg', role: 'switch', type: 'button', onclick: () => setT('on', !T().on) }, h('i'));
    const name = h('input', { type: 'text', class: 'tname', maxlength: 40 }); name.addEventListener('input', () => setT('name', name.value));
    const meter = h('div', { class: 'meter' }, h('i'));
    const del = h('button', { class: 'btn ghost sm', type: 'button', title: 'Удалить дорожку', onclick: () => { patch({ audio: { tracks: S.settings.audio.tracks.filter((_, k) => k !== i) } }); renderTracks(); } }, '×');
    const seg = SegG(() => T().type, v => setT('type', v), () => [['app', 'Приложение'], ['system', 'Вся система'], ['except', 'Всё, кроме…'], ['mic', 'Микрофон']]);
    const src = h('select'), stat = h('div', { class: 'tstat' }), refresh = Btn('↻', loadApps, 'ghost sm');
    const fill = () => {
      const t = T(), isApp = t.type === 'app' || t.type === 'except'; const o = [];
      if (isApp) {
        o.push(['', '— выберите приложение —']); const seen = new Set();
        apps.forEach(a => { seen.add(a.exe.toLowerCase()); o.push([a.exe, a.exe + (a.title ? ' — ' + a.title.slice(0, 40) : '')]); });
        if (t.exe && !seen.has(t.exe.toLowerCase())) o.splice(1, 0, [t.exe, t.exe + ' — сейчас не запущено']); o.push(['__custom', 'Другое (ввести имя)…']);
      } else { const d = t.type === 'mic' ? S.dev.capture : S.dev.render; o.push(['', 'Устройство по умолчанию']); d.forEach(x => o.push([x.id, x.name + (x.default ? ' · по умолчанию' : '')])); if (t.device && !d.some(x => x.id === t.device)) o.push([t.device, 'Устройство недоступно']); }
      const sig = JSON.stringify(o); if (src.dataset.sig !== sig) { src.dataset.sig = sig; src.innerHTML = ''; o.forEach(x => src.append(h('option', { value: x[0] }, x[1]))); }
      src.value = isApp ? (t.exe || '') : (t.device || '');
    };
    src.addEventListener('change', () => {
      const t = T(); let v = src.value;
      if (t.type === 'app' || t.type === 'except') { if (v === '__custom') { v = (prompt('Имя процесса, например Discord.exe', t.exe || '') || '').trim(); if (!v) return fill(); } setT('exe', v); } else setT('device', v);
    });
    const gain = RangeG(() => T().gain || 0, v => setT('gain', v), -20, 20, 0.5, v => (v > 0 ? '+' : '') + v.toFixed(1) + ' дБ');
    const off = h('input', { type: 'number', min: -500, max: 500, step: 5 }); off.addEventListener('change', () => setT('offset', Number(off.value) || 0));
    const row = h('div', { class: 'trk' }, h('div', { class: 'th' }, on, name, meter, del), h('div', { class: 'tb' }, seg), h('div', { class: 'tb' }, src, refresh),
      h('div', { class: 'tf' }, h('label', {}, 'Громкость', gain), h('label', {}, 'Сдвиг', off, 'мс')), stat);
    REG(() => {
      const t = T(); row.classList.toggle('off', !t.on); on.setAttribute('aria-checked', !!t.on); meter.dataset.id = t.id;
      refresh.hidden = !(t.type === 'app' || t.type === 'except'); if (document.activeElement !== name) name.value = t.name || ''; if (document.activeElement !== off) off.value = t.offset || 0; fill();
      const st = S.tracks.find(x => x.id === t.id), live = S.monitoring || S.rec.state !== 'idle';
      stat.textContent = !live || !st ? '' : st.status === 'ok' ? 'Подключено · ' + st.detail : st.status === 'waiting' ? st.detail : st.status === 'error' ? 'Ошибка: ' + st.detail : 'Подключаю…';
    });
    return row;
  }
  function buildAudio() {
    const p = h('div'); p.append(h('div', { class: 'sec' }, 'Дорожки'), h('div', { id: 'tlist' }));
    p.append(h('div', { class: 'row' }, h('div', { class: 'lab' }, h('span', {}, 'Список')), h('div', { class: 'ctl' }, Btn('+ Добавить дорожку', () => {
      const a = S.settings.audio.tracks; if (a.length >= 6) return toast({ kind: 'error', msg: 'Максимум 6 дорожек' });
      patch({ audio: { tracks: a.concat([{ id: 't' + (Date.now() % 100000), name: 'Дорожка ' + (a.length + 1), on: true, type: 'app', exe: '', device: '', gain: 0, offset: 0 }]) } }); renderTracks();
    }), Btn('Обновить приложения', loadApps, 'ghost'))));
    p.append(h('div', { class: 'note' }, 'Каждая дорожка пишется отдельным аудиопотоком в файле — в Premiere они откроются как отдельные дорожки. Звук отдельного приложения снимается средствами Windows, без драйверов и виртуальных кабелей (нужна Windows 10 2004 или новее). «Всё, кроме…» — вся система без выбранного приложения.'));
    p.append(h('div', { class: 'sec' }, 'Формат'));
    p.append(Row('Кодек звука', Seg('audio.codec', [['aac', 'AAC'], ['flac', 'FLAC'], ['opus', 'Opus']]), 'Для MP4 всегда AAC'));
    p.append(Row('Битрейт звука', Sel('audio.bitrate', () => [[192, '192 кбит/с'], [256, '256 кбит/с'], [320, '320 кбит/с']], true)));
    p.append(Row('Отдельные файлы дорожек', [Toggle('audio.wav'), Seg('audio.wavFormat', [['wav', 'WAV'], ['flac', 'FLAC']])], 'Копия каждой дорожки без сжатия рядом с видео'));
    return p;
  }

  const fmtList = () => [['auto', 'Авто']].concat(camOpts.map(o => [o.format, FMT_L[o.format] || o.format]));
  function sizesFor() { const f = get('webcam.format'); const src = f === 'auto' ? camOpts : camOpts.filter(o => o.format === f); const m = new Map(); src.forEach(o => o.sizes.forEach(s => m.set(s.size, (m.get(s.size) || new Set()).add(0) && s))); return Array.from(m.values()); }
  function fpsFor() { const s = sizesFor().find(x => x.size === get('webcam.size')); return s ? s.fps : [get('webcam.fps')]; }
  async function loadCamOpts() {
    const d = get('webcam.device'); if (!d) { camOpts = []; return sync(); }
    const r = await api('cam/options', { device: d }); if (d !== get('webcam.device')) return; camOpts = r.options || [];
    if (camOpts.length && !sizesFor().some(x => x.size === get('webcam.size'))) { const o = camOpts.find(x => x.format === 'mjpeg') || camOpts[0], s = o.sizes.find(x => x.size === '1280x720') || o.sizes[0]; patch({ webcam: { size: s.size, fps: s.fps.indexOf(30) >= 0 ? 30 : s.fps[s.fps.length - 1] } }); }
    sync();
  }
  function buildCam() {
    const p = h('div'), snap = SnapBlock('cam');
    p.append(Row('Запись камеры', Seg('webcam.mode', [['off', 'Выкл'], ['file', 'Отдельный файл'], ['track', 'Дорожка в видео']]), 'Отдельный файл удобен для монтажа: камеру можно двигать и менять размер'));
    const body = h('div');
    body.append(Row('Камера', [Sel('webcam.device', () => { const c = S.dev.cams.map(x => [x, x]); return [['', S.dev.cams.length ? '— выберите камеру —' : 'Камеры не найдены']].concat(c); }), Btn('↻', async () => { await api('refresh', {}); }, 'ghost sm')]));
    body.append(Row('Формат', Sel('webcam.format', fmtList), 'MJPEG даёт больше кадров, YUY2 — без сжатия'));
    body.append(Row('Разрешение', Sel('webcam.size', () => { const s = sizesFor(); return s.length ? s.map(x => [x.size, x.size.replace('x', '×')]) : [[get('webcam.size'), get('webcam.size').replace('x', '×')]]; })));
    body.append(Row('Кадров в секунду', Sel('webcam.fps', () => fpsFor().map(x => [x, String(x)]), true)));
    body.append(Row('Сжатие', Seg('webcam.codec', [['h264', 'H.264'], ['copy', 'Как есть (без нагрузки)']]), '«Как есть» работает для камер с MJPEG или H.264 и без зеркала'));
    body.append(Row('Битрейт', Range('webcam.bitrate', 2, 40, 1, v => v + ' Мбит/с')));
    body.append(Row('Звук микрофона в файле камеры', Toggle('webcam.mic'), 'По нему удобно совместить камеру и основное видео в монтаже'));
    body.append(Row('Зеркало', Toggle('webcam.mirror')));
    body.append(Row('Проверка', [snap.btn, Btn('Настройки драйвера', () => api('cam/dialog', { device: get('webcam.device') }), 'ghost')], 'Яркость, экспозиция, фокус — окно драйвера камеры'));
    body.append(snap.img); p.append(body);
    REG(() => { body.hidden = get('webcam.mode') === 'off'; });
    return p;
  }

  const KEYS = (() => {
    const m = {}; for (let i = 1; i <= 24; i++) m['F' + i] = 0x6F + i; for (let i = 0; i < 26; i++) m['Key' + String.fromCharCode(65 + i)] = 0x41 + i;
    for (let i = 0; i < 10; i++) { m['Digit' + i] = 0x30 + i; m['Numpad' + i] = 0x60 + i; }
    return Object.assign(m, { Space: 0x20, Pause: 0x13, ScrollLock: 0x91, Insert: 0x2D, Delete: 0x2E, Home: 0x24, End: 0x23, PageUp: 0x21, PageDown: 0x22, ArrowLeft: 0x25, ArrowUp: 0x26, ArrowRight: 0x27, ArrowDown: 0x28, Backquote: 0xC0 });
  })();
  function HotkeyBtn() {
    const b = h('button', { class: 'key', type: 'button' }); let wait = false;
    b.addEventListener('click', () => { wait = true; b.classList.add('wait'); b.textContent = 'Нажмите…'; b.focus(); });
    b.addEventListener('keydown', e => {
      if (!wait) return; e.preventDefault(); e.stopPropagation();
      if (e.code === 'Escape') { wait = false; b.classList.remove('wait'); return sync(); }
      if (/^(Control|Shift|Alt|Meta)/.test(e.code) || !KEYS[e.code]) return;
      const mods = (e.altKey ? 1 : 0) | (e.ctrlKey ? 2 : 0) | (e.shiftKey ? 4 : 0) | (e.metaKey ? 8 : 0);
      const nm = e.code.replace(/^Key|^Digit/, '').replace('Arrow', '↔'.slice(0, 0)); const label = (e.ctrlKey ? 'Ctrl+' : '') + (e.altKey ? 'Alt+' : '') + (e.shiftKey ? 'Shift+' : '') + (e.metaKey ? 'Win+' : '') + nm;
      wait = false; b.classList.remove('wait'); patch({ hotkey: { mods, vk: KEYS[e.code], label } });
    });
    b.addEventListener('blur', () => { if (wait) { wait = false; b.classList.remove('wait'); sync(); } });
    REG(() => { if (!wait) b.textContent = get('hotkey.label'); });
    return b;
  }
  function buildFiles() {
    const p = h('div');
    p.append(Row('Папка для записей', [Txt('output.folder'), Btn('Выбрать…', async () => { const r = await api('pick-folder', { path: get('output.folder') }); if (r.path) set('output.folder', r.path); }), Btn('Открыть', () => api('open', { what: 'folder' }), 'ghost')]));
    p.append(Row('Контейнер', Seg('output.container', [['mp4', 'MP4'], ['mkv', 'MKV']]), 'Запись идёт в MKV и надёжна при сбоях, MP4 собирается после остановки за пару секунд'));
    p.append(Row('Папка для каждой записи', Toggle('output.sessionFolder'), 'Видео, камера и дорожки лежат вместе'));
    const k = Row('Оставлять MKV', Toggle('output.keepMkv'), 'Исходный MKV после сборки MP4'); REG(() => { k.hidden = get('output.container') !== 'mp4'; }); p.append(k);
    p.append(Row('Открывать папку после записи', Toggle('output.openAfter')));
    const hk = Row('Горячая клавиша', HotkeyBtn(), 'Старт и стоп записи, работает поверх игр'); dynHint(hk, () => S.hotkey.err || 'Старт и стоп записи, работает поверх игр'); p.append(hk);
    p.append(Row('Лёгкий режим при записи', Toggle('ui.lite'), 'Отключает анимации окна, пока идёт запись'));
    return p;
  }
  function renderSys() {
    const box = $('#sysbox'); if (!box) return; const E = caps(), yes = (f, c) => !!(E[f] && E[f][c]); box.innerHTML = '';
    box.append(h('div', { class: 'comp' }, 'FFmpeg', h('b', {}, S.ready.ffmpeg ? (S.caps.version || 'установлен').replace(/^ffmpeg version /, '').slice(0, 34) : 'не установлен'),
      'Аудио-модуль', h('b', {}, S.ready.helper ? 'готов' : 'не собран'), 'Захват экрана (GPU)', h('b', {}, S.caps.ddagrab ? 'Desktop Duplication' : 'GDI (медленнее)'), 'Горячая клавиша', h('b', {}, S.hotkey.ok ? S.settings.hotkey.label : (S.hotkey.err || 'не активна'))));
    const g = h('div', { class: 'chk' }); ['nvenc', 'amf', 'qsv', 'cpu'].forEach(f => ['h264', 'hevc', 'av1'].forEach(c => g.append(h('span', { class: yes(f, c) ? 'y' : '' }, (yes(f, c) ? '✓ ' : '– ') + ENC_L[f] + ' ' + COD_L[c])))); box.append(g);
  }
  function buildSys() {
    const p = h('div'); p.append(h('div', { class: 'sec' }, 'Компоненты'), h('div', { id: 'sysbox' }));
    p.append(h('div', { class: 'row' }, h('div', { class: 'lab' }, h('span', {}, 'Обслуживание')), h('div', { class: 'ctl' }, Btn('Проверить кодеры', async () => { toast({ kind: 'ok', msg: 'Проверяю кодеры…' }); await api('setup', { action: 'reprobe' }); toast({ kind: 'ok', msg: 'Готово' }); }), Btn('Переустановить', () => api('setup', { action: 'run' }), 'ghost'), Btn('Открыть лог', () => api('open', { what: 'logs' }), 'ghost'))));
    p.append(h('div', { class: 'row' }, h('div', { class: 'lab' }, h('span', {}, 'Приложение')), h('div', { class: 'ctl' }, Btn('Выйти из MaxRec', () => { api('quit', {}); }))));
    p.append(h('div', { class: 'note' }, 'Если запись не стартует, откройте лог и пришлите последние строки — по ним видно, на каком шаге остановился кодер.'));
    return p;
  }

  async function loadApps() { const r = await api('apps'); apps = r.apps || []; sync(); }

  /* ---------- вкладки ---------- */
  const TABS = [['video', 'Видео', buildVideo], ['audio', 'Звук', buildAudio], ['cam', 'Камера', buildCam], ['files', 'Файлы', buildFiles], ['sys', 'Система', buildSys]];
  function placeInd() { const b = $('#tabs button.on'), i = $('#tabs .ind'); if (!b) return; i.style.width = (b.offsetWidth - 24) + 'px'; i.style.transform = 'translateX(' + (b.offsetLeft + 12) + 'px)'; }
  function openTab(id) {
    const was = tab; tab = id;
    $$('#tabs button').forEach(b => b.classList.toggle('on', b.dataset.t === id)); $$('.page').forEach(p => p.classList.toggle('on', p.dataset.t === id)); placeInd(); sync();
    if (id === 'audio') { api('monitor', { on: true }); loadApps(); } else if (was === 'audio') api('monitor', { on: false });
    if (id === 'cam') { if (!get('webcam.device') && S.dev.cams.length) set('webcam.device', S.dev.cams[0]); else loadCamOpts(); } if (id === 'sys') renderSys();
  }
  function buildUI() {
    const tabs = $('#tabs'), pages = $('#pages');
    TABS.forEach(t => { tabs.append(h('button', { type: 'button', 'data-t': t[0], onclick: () => openTab(t[0]) }, t[1])); const pg = h('div', { class: 'page', 'data-t': t[0] }); pg.append(t[2]()); pages.append(pg); });
    renderTracks(); openTab('video'); document.fonts && document.fonts.ready.then(() => { placeInd(); placePills(); });
  }

  /* ---------- сцена ---------- */
  const two = n => String(n).padStart(2, '0');
  function fmtTime(ms) { const s = Math.max(0, Math.floor(ms / 1000)); return [two(Math.floor(s / 3600)), two(Math.floor(s / 60) % 60), two(s % 60)]; }
  function tickTime() {
    if (!S) return; const rec = S.rec.state === 'recording', p = fmtTime(rec ? Date.now() - S.rec.startedAt : 0), el = $('#time'), sp = $$('span', el);
    p.forEach((v, i) => { if (sp[i].textContent !== v) sp[i].textContent = v; });
    document.title = rec ? '● ' + p.join(':') + ' — MaxRec' : 'MaxRec';
  }
  setInterval(tickTime, 250);
  const typeSrc = t => t.type === 'app' ? t.exe : t.type === 'except' ? 'всё, кроме ' + t.exe : t.type === 'mic' ? 'микрофон' : 'вся система';
  function renderMeters() {
    const T = activeTracks(), box = $('#meters'), sig = T.map(t => t.id + '|' + t.name).join(',');
    if (box.dataset.sig !== sig) { box.dataset.sig = sig; box.innerHTML = ''; T.forEach((t, i) => box.append(h('div', { class: 'm', 'data-id': t.id, style: 'animation-delay:' + i * 70 + 'ms' }, h('span', { class: 'mn' }, t.name), h('span', { class: 'mb' }, h('i')), h('span', { class: 'ms' })))); }
    const live = S.monitoring || S.rec.state === 'recording';
    T.forEach(t => {
      const el = $('.m[data-id="' + t.id + '"]', box); if (!el) return; const st = S.tracks.find(x => x.id === t.id);
      $('.ms', el).textContent = live ? (!st ? '…' : st.status === 'ok' ? 'в эфире' : st.status === 'waiting' ? 'ждёт ' + t.exe : st.status === 'error' ? 'ошибка' : '…') : typeSrc(t);
      el.classList.toggle('err', !!st && st.status === 'error' && live);
    });
  }
  const sizeLbl = n => n > 1073741824 ? (n / 1073741824).toFixed(2) + ' ГБ' : n >= 1048576 ? Math.round(n / 1048576) + ' МБ' : Math.max(0, Math.round(n / 1024)) + ' КБ';
  const hotLabel = () => S.settings.hotkey.label;
  function renderStage() {
    if (!S) return; const st = S.rec.state, rec = st === 'recording', can = S.ready.ffmpeg && S.ready.helper && S.caps.probed && !S.setup.running;
    document.body.classList.toggle('rec', rec); document.body.classList.toggle('busy', st === 'starting' || st === 'stopping'); document.body.classList.toggle('lite', !!S.settings.ui.lite && rec);
    const b = $('#rec'); b.disabled = !can || st === 'starting' || st === 'stopping';
    $('#sub').textContent = st === 'recording' ? S.rec.info : st === 'starting' ? 'Запускаю запись…' : st === 'stopping' ? 'Сохраняю файлы…' : S.rec.error ? S.rec.error : can ? 'Готов · ' + hotLabel() + ' или нажмите на кнопку' : 'Идёт подготовка…';
    const s = S.rec.stats; $('#stats').textContent = rec && s ? s.fps.toFixed(0) + ' к/с · потеряно ' + s.drop + ' · ' + sizeLbl(s.size) + (s.speed && s.speed < 0.95 && Date.now() - S.rec.startedAt > 8000 ? ' · не успевает (' + s.speed.toFixed(2) + '×)' : '') : '';
    $('#chipProbe').hidden = !(S.ready.ffmpeg && !S.caps.probed);
    const ce = $('#chipEnc'); ce.hidden = !S.caps.probed; ce.textContent = ENC_L[autoEnc()] + ' · ' + COD_L[get('video.codec')]; ce.classList.toggle('on', rec);
    const ck = $('#chipKey'); ck.textContent = hotLabel() + (S.hotkey.err ? ' · занято' : ''); ck.hidden = !S.ready.helper;
    const live = S.monitoring || st === 'recording' || st === 'starting'; if (!live) for (const id in LV) { LV[id].v = 0; LV[id].hist = []; }
    renderMeters(); renderLast(); sd();
  }
  function renderLast() {
    const box = $('#last'), f = S.rec.files || [], show = S.rec.state === 'idle' && f.length, sig = show ? f.map(x => x.path).join('|') : '';
    box.hidden = !show; if (box.dataset.sig === sig) return; box.dataset.sig = sig; box.innerHTML = ''; if (!show) return;
    box.append(h('div', { class: 'f' }, h('span', {}, 'Последняя запись'), h('a', { onclick: () => api('open', { what: 'file', path: f[0].path }) }, 'Показать в папке')));
    f.forEach(x => box.append(h('div', { class: 'f' }, h('span', {}, x.path.split(/[\\/]/).pop()), h('span', {}, sizeLbl(x.size)))));
  }
  function renderSetup() {
    const need = !S.ready.ffmpeg || !S.ready.helper || S.setup.running || !!S.setup.error, el = $('#setup'); el.classList.toggle('off', !need); if (!need) return;
    const err = S.setup.error; $('#sStep').textContent = err ? 'Не удалось завершить установку' : (S.setup.step || 'Подготовка…');
    $('#sBar').hidden = !!err; $('#sBar').style.setProperty('--v', (S.setup.pct || 0) / 100); $('#sPct').textContent = err ? '' : Math.round(S.setup.pct || 0) + '%';
    const eb = $('#sErr'); eb.hidden = !err; eb.textContent = err || ''; const bt = $('#sBtns'); bt.hidden = !err;
    if (err && !bt.dataset.on) { bt.dataset.on = '1'; bt.append(Btn('Повторить', () => api('setup', { action: 'run' })), Btn('Указать ffmpeg.exe', async () => { const p = (prompt('Полный путь к ffmpeg.exe', '') || '').trim(); if (p) { const r = await api('setup', { action: 'local', path: p }); if (r.error) toast({ kind: 'error', msg: r.error }); } }, 'ghost'), Btn('Открыть лог', () => api('open', { what: 'logs' }), 'ghost')); }
  }

  /* ---------- радиальный индикатор ---------- */
  const cv = $('#radial'), g = cv.getContext('2d'); let DPR = 1, dq = false, lastDraw = 0; const LV = {};
  function fit() { DPR = Math.min(2, window.devicePixelRatio || 1); cv.width = 440 * DPR; cv.height = 440 * DPR; }
  function draw() {
    if (!S) return; g.setTransform(DPR, 0, 0, DPR, 0, 0); g.clearRect(0, 0, 440, 440);
    const T = activeTracks(), n = Math.max(1, T.length), per = Math.max(10, Math.floor(100 / n)), gap = 0.24, arc = Math.PI * 2 / n; g.lineCap = 'round'; g.lineWidth = 2.2;
    T.forEach((t, k) => {
      const L = LV[t.id] || (LV[t.id] = { v: 0, hist: [] }), a0 = -Math.PI / 2 + k * arc + gap / 2, span = arc - gap;
      for (let j = 0; j < per; j++) {
        const val = L.hist[j] || 0, a = a0 + span * (j / per), len = 2 + val * 60, c = Math.cos(a), s = Math.sin(a);
        g.strokeStyle = 'rgba(255,255,255,' + (0.16 + 0.84 * (1 - j / per) * Math.min(1, 0.2 + val * 1.6)).toFixed(3) + ')';
        g.beginPath(); g.moveTo(220 + c * 106, 220 + s * 106); g.lineTo(220 + c * (106 + len), 220 + s * (106 + len)); g.stroke();
      }
    });
    $$('.m').forEach(m => { const L = LV[m.dataset.id]; $('.mb i', m).style.transform = 'scaleX(' + (L ? L.v : 0).toFixed(3) + ')'; });
    $$('.meter').forEach(m => { const L = LV[m.dataset.id]; $('i', m).style.transform = 'scaleX(' + (L ? L.v : 0).toFixed(3) + ')'; });
  }
  function sd() { if (dq || document.hidden) return; dq = true; requestAnimationFrame(() => { dq = false; const now = performance.now(); if (S && S.settings.ui.lite && S.rec.state === 'recording' && now - lastDraw < 80) return; lastDraw = now; draw(); }); }
  const dbmap = l => Math.max(0, Math.min(1, (20 * Math.log10(Math.max(l, 1e-5)) + 54) / 54));
  function onLevels(L) {
    for (const id in L) { const q = LV[id] || (LV[id] = { v: 0, hist: [] }), v = dbmap(L[id]); q.v = v > q.v ? v : q.v * 0.8 + v * 0.2; q.hist.unshift(q.v); if (q.hist.length > 100) q.hist.length = 100; }
    sd();
  }

  /* ---------- уведомления и связь ---------- */
  function toast(t) {
    const e = h('div', { class: 'toast ' + (t.kind || '') }, t.msg); $('#toasts').append(e); const ttl = t.kind === 'error' ? 9000 : 5000;
    setTimeout(() => { e.classList.add('out'); setTimeout(() => e.remove(), 400); }, ttl);
  }
  function onState(st) {
    const keep = pt || Date.now() - lastPatch < 800; if (keep && S) st.settings = S.settings; const first = !S; S = st;
    if (first) buildUI();
    const sig = S.settings.audio.tracks.map(t => t.id).join(','); if (sig !== tsig) renderTracks();
    sync(); renderStage(); renderSetup(); if (tab === 'sys') renderSys();
  }
  function connect() {
    const es = new EventSource('/api/events');
    es.addEventListener('state', e => onState(JSON.parse(e.data))); es.addEventListener('levels', e => onLevels(JSON.parse(e.data))); es.addEventListener('toast', e => toast(JSON.parse(e.data)));
    es.onopen = () => $('#lost').classList.remove('on'); es.onerror = () => { setTimeout(() => { if (es.readyState !== 1) $('#lost').classList.add('on'); }, 2500); };
  }
  $('#rec').addEventListener('click', requestRecording);
  document.addEventListener('keydown', e => { if (e.code === 'Space' && !e.repeat && !/^(INPUT|SELECT|BUTTON|TEXTAREA)$/.test((e.target.tagName || ''))) { e.preventDefault(); if (!$('#rec').disabled) requestRecording(); } });
  document.addEventListener('visibilitychange', () => { if (!document.hidden) sd(); });
  window.addEventListener('resize', () => { placeInd(); placePills(); });
  window.addEventListener('beforeunload', () => { try { navigator.sendBeacon && S && S.monitoring && fetch('/api/monitor', { method: 'POST', keepalive: true, headers: { 'X-MaxRec': '1' }, body: JSON.stringify({ on: false }) }); } catch (e) {} });
  fit(); api('state').then(st => { onState(st); connect(); });
})();
