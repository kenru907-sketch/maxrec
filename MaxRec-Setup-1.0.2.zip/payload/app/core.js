'use strict';
// MaxRec core: настройки, сборка команд ffmpeg, «питатель» звуковых дорожек, парсеры.
const path = require('path');

const RATE = 48000, BPF = 8, PRIMER = 2048; // float32 stereo 48 kHz

const ENC_NAME = {
  nvenc: { h264: 'h264_nvenc', hevc: 'hevc_nvenc', av1: 'av1_nvenc' },
  amf:   { h264: 'h264_amf',   hevc: 'hevc_amf',   av1: 'av1_amf' },
  qsv:   { h264: 'h264_qsv',   hevc: 'hevc_qsv',   av1: 'av1_qsv' },
  cpu:   { h264: 'libx264',    hevc: 'libx265',    av1: 'libsvtav1' },
};

function defaults(videosDir) {
  const T = (id, name, type, exe) => ({ id, name, on: true, type, exe: exe || '', device: '', gain: 0, offset: 0 });
  return {
    v: 1,
    video: { monitor: 0, fps: 60, encoder: 'auto', codec: 'h264', rate: 'vbr', bitrate: 0, cq: 19, quality: 'high', cursor: true, scale: 'native' },
    audio: { codec: 'aac', bitrate: 320, wav: false, wavFormat: 'wav',
      tracks: [ T('game', 'Игра', 'app'), T('discord', 'Discord', 'app', 'Discord.exe'), T('pc', 'ПК', 'system'), T('mic', 'Микрофон', 'mic') ] },
    webcam: { mode: 'off', device: '', size: '1280x720', fps: 30, format: 'auto', codec: 'h264', bitrate: 8, mic: true, mirror: false },
    output: { folder: path.join(videosDir, 'MaxRec'), container: 'mp4', sessionFolder: true, keepMkv: false, openAfter: false },
    hotkey: { mods: 0, vk: 0x78, label: 'F9' },
    ui: { lite: true },
  };
}

const BAD = new Set(['__proto__', 'constructor', 'prototype']);
function deepMerge(base, patch) {
  if (Array.isArray(patch)) return patch.map(x => (x && typeof x === 'object' && !Array.isArray(x)) ? deepMerge({}, x) : x);
  if (patch && typeof patch === 'object') {
    const out = (base && typeof base === 'object' && !Array.isArray(base)) ? Object.assign({}, base) : {};
    for (const k of Object.keys(patch)) { if (BAD.has(k)) continue; out[k] = deepMerge(out[k], patch[k]); }
    return out;
  }
  return patch === undefined ? base : patch;
}

const clamp = (n, a, b, d) => { n = Number(n); return Number.isFinite(n) ? Math.min(b, Math.max(a, n)) : d; };
const pick = (v, list, d) => list.includes(v) ? v : d;
function sanitize(s, def) {
  const obj = x => x && typeof x === 'object' && !Array.isArray(x);
  s = obj(s) ? { ...s } : {};
  for (const key of ['video', 'audio', 'webcam', 'output']) s[key] = { ...def[key], ...(obj(s[key]) ? s[key] : {}) };
  const v = s.video, a = s.audio, w = s.webcam, o = s.output;
  v.monitor = clamp(v.monitor, 0, 9, 0) | 0; v.fps = clamp(v.fps, 10, 240, 60) | 0;
  v.encoder = pick(v.encoder, ['auto', 'nvenc', 'amf', 'qsv', 'cpu'], 'auto');
  v.codec = pick(v.codec, ['h264', 'hevc', 'av1'], 'h264'); v.rate = pick(v.rate, ['vbr', 'cq'], 'vbr');
  v.bitrate = clamp(v.bitrate, 0, 400, 0); v.cq = clamp(v.cq, 10, 40, 19) | 0;
  v.quality = pick(v.quality, ['speed', 'balanced', 'high', 'max'], 'high'); v.scale = pick(String(v.scale), ['native', '1440', '1080', '720'], 'native');
  v.cursor = !!v.cursor;
  a.codec = pick(a.codec, ['aac', 'flac', 'pcm', 'opus'], 'aac'); a.bitrate = clamp(a.bitrate, 64, 512, 320) | 0; a.wav = !!a.wav; a.wavFormat = pick(a.wavFormat, ['wav', 'flac'], 'wav');
  if (!Array.isArray(a.tracks)) a.tracks = def.audio.tracks;
  const ids = new Set();
  a.tracks = a.tracks.filter(obj).slice(0, 6).map((t, i) => {
    let id = String(t.id || '').replace(/[^\w-]/g, '').slice(0, 20);
    if (!id || BAD.has(id) || ids.has(id)) { id = 't' + i; while (ids.has(id)) id += '_'; }
    ids.add(id);
    return { id, name: String(t.name || 'Дорожка ' + (i + 1)).slice(0, 40), on: !!t.on,
    type: pick(t.type, ['system', 'mic', 'app', 'except'], 'system'), exe: String(t.exe || '').replace(/[^\w.\- ()]/g, '').slice(0, 80), device: String(t.device || '').slice(0, 200),
    gain: clamp(t.gain, -30, 30, 0), offset: clamp(t.offset, -500, 500, 0) | 0 };
  });
  w.mode = pick(w.mode, ['off', 'file', 'track'], 'off'); w.fps = clamp(w.fps, 5, 120, 30) | 0; w.bitrate = clamp(w.bitrate, 1, 100, 8);
  w.size = /^\d{2,5}x\d{2,5}$/.test(w.size) ? w.size : '1280x720'; w.format = String(w.format || 'auto').replace(/[^\w]/g, '').slice(0, 20) || 'auto';
  w.codec = pick(w.codec, ['h264', 'copy'], 'h264'); w.mic = !!w.mic; w.mirror = !!w.mirror; w.device = String(w.device || '').slice(0, 200);
  o.container = pick(o.container, ['mp4', 'mkv'], 'mp4'); o.sessionFolder = !!o.sessionFolder; o.keepMkv = !!o.keepMkv; o.openAfter = !!o.openAfter;
  o.folder = String(o.folder || def.output.folder).slice(0, 400);
  s.hotkey = { mods: clamp(s.hotkey && s.hotkey.mods, 0, 15, 0) | 0, vk: clamp(s.hotkey && s.hotkey.vk, 1, 254, 0x78) | 0, label: String((s.hotkey && s.hotkey.label) || 'F9').slice(0, 30) };
  s.ui = { lite: !(s.ui && s.ui.lite === false) };
  return s;
}

function trackActive(t) { return !!t.on && ((t.type === 'app' || t.type === 'except') ? !!t.exe : true); }
function autoBitrate(w, h, fps) { return Math.max(8, Math.min(150, Math.round(w * h * fps * 0.32 / 1e6))); }

function geometry(s, mon) {
  const sw = (mon && mon.w) || 1920, sh = (mon && mon.h) || 1080;
  let w = sw, h = sh; const th = parseInt(s.video.scale, 10);
  if (th && th < sh) { h = th; w = Math.round(sw * th / sh); }
  w -= w % 2; h -= h % 2;
  return { sw, sh, w, h, scaled: w !== sw || h !== sh };
}

// ---------- параметры кодера ----------
// FFmpeg builds advertise different spellings; Spatial AQ is optional.
function nvencSpatialOption(help) {
  const has = name => new RegExp('^[ \t]*-' + name + '(?=[ \t]|$)', 'm').test(help);
  return has('spatial-aq') ? 'spatial-aq' : has('spatial_aq') ? 'spatial_aq' : '';
}
function encArgs(enc, codec, p, stream = 0, caps) {
  const C = '-c:v:' + stream;
  const O = n => '-' + (n.endsWith(':v') ? n : n + ':v') + ':' + stream;
  const br = p.bitrate, maxr = Math.round(br * 1.5), buf = Math.round(br * 2), g = String(Math.max(1, Math.round(p.fps * 2)));
  const q = p.quality, a = [C, ENC_NAME[enc][codec]];
  if (enc === 'nvenc') {
    a.push(O('preset'), { speed: 'p3', balanced: 'p4', high: 'p5', max: 'p7' }[q], O('tune'), 'hq');
    if (p.mode === 'cq') a.push(O('rc'), 'vbr', O('cq'), String(p.cq), O('b:v'), '0', O('maxrate'), Math.max(50, br * 2) + 'M');
    else a.push(O('rc'), 'vbr', O('b:v'), br + 'M', O('maxrate'), maxr + 'M', O('bufsize'), buf + 'M');
    const spatial = caps?.nvencSpatial?.[codec];
    if (spatial === 'spatial-aq' || spatial === 'spatial_aq') a.push(O(spatial), '1');
    a.push(O('g'), g);
    if (codec === 'h264') a.push(O('bf'), '2', O('profile'), 'high'); else if (codec === 'hevc') a.push(O('profile'), 'main');
  } else if (enc === 'amf') {
    a.push(O('quality'), { speed: 'speed', balanced: 'balanced', high: 'quality', max: 'quality' }[q]);
    if (p.mode === 'cq') { a.push(O('rc'), 'cqp', O('qp_i'), String(p.cq - 1), O('qp_p'), String(p.cq)); if (codec === 'h264') a.push(O('qp_b'), String(p.cq + 2)); }
    else a.push(O('rc'), 'vbr_peak', O('b:v'), br + 'M', O('maxrate'), maxr + 'M');
    a.push(O('g'), g); if (codec === 'h264') a.push(O('profile'), 'high');
  } else if (enc === 'qsv') {
    a.push(O('preset'), { speed: 'veryfast', balanced: 'medium', high: 'slow', max: 'veryslow' }[q]);
    if (p.mode === 'cq') a.push(O('global_quality'), String(p.cq)); else a.push(O('b:v'), br + 'M', O('maxrate'), maxr + 'M');
    a.push(O('g'), g); if (codec === 'h264') a.push(O('profile'), 'high');
  } else {
    if (codec === 'av1') {
      a.push(O('preset'), String({ speed: 12, balanced: 10, high: 8, max: 6 }[q]));
      if (p.mode === 'cq') a.push(O('crf'), String(p.cq + 8)); else a.push(O('b:v'), br + 'M');
    } else {
      a.push(O('preset'), { speed: 'superfast', balanced: 'veryfast', high: 'faster', max: 'medium' }[q]);
      if (p.mode === 'cq') a.push(O('crf'), String(p.cq - 1)); else a.push(O('b:v'), br + 'M', O('maxrate'), maxr + 'M', O('bufsize'), buf + 'M');
      if (codec === 'h264') a.push(O('profile'), 'high');
    }
    a.push(O('g'), g);
  }
  return a;
}
const COLOR = ['-colorspace', 'bt709', '-color_primaries', 'bt709', '-color_trc', 'bt709', '-color_range', 'tv'];

function variantsFor(enc, geo, caps) {
  if (!caps.ddagrab) return ['gdi'];
  if (enc === 'cpu') return ['sw'];
  if (enc === 'qsv') return geo.scaled ? ['sw'] : ['qsv', 'sw'];
  return geo.scaled ? ['sw'] : ['direct', 'sw'];
}

function videoInput(c) {
  const v = c.s.video, g = c.geo, cur = v.cursor ? 1 : 0;
  if (c.testSrc) return { input: ['-re', '-readrate_initial_burst', '0', '-f', 'lavfi', '-i', c.testSrc], vf: '' };
  if (c.variant === 'gdi') {
    const chain = [];
    if (g.scaled) chain.push(`scale=${g.w}:${g.h}:flags=bicubic`);
    chain.push('scale=out_color_matrix=bt709:out_range=tv', 'format=' + (c.enc === 'cpu' ? 'yuv420p' : 'nv12'));
    return { input: ['-f', 'gdigrab', '-framerate', String(v.fps), '-draw_mouse', String(cur), '-i', 'desktop'], vf: chain.join(',') };
  }
  let f = `ddagrab=output_idx=${c.monIdx}:framerate=${v.fps}:draw_mouse=${cur}`;
  if (c.variant === 'qsv') f += ',hwmap=derive_device=qsv,format=qsv';
  else if (c.variant === 'sw') {
    f += ',hwdownload,format=bgra';
    if (g.scaled) f += `,scale=${g.w}:${g.h}:flags=bicubic:out_color_matrix=bt709:out_range=tv`; else f += ',scale=out_color_matrix=bt709:out_range=tv';
    f += ',format=' + (c.enc === 'cpu' ? 'yuv420p' : 'nv12');
  }
  return { input: ['-f', 'lavfi', '-i', f], vf: '' };
}

const PROBE = ['-probesize', '32', '-analyzeduration', '0'];
// In current FFmpeg builds -thread_queue_size is an output-only option.
const audioIn = port => [...PROBE, '-f', 'f32le', '-ar', '48000', '-ac', '2', '-i', 'tcp://127.0.0.1:' + port];
const safe = s => String(s).replace(/[\\/:*?"<>|\x00-\x1f]/g, '_').trim().replace(/[. ]+$/, '') || 'track';

function audioCodecArgs(a, container) {
  const codec = container === 'mp4' ? 'aac' : a.codec;
  if (codec === 'flac') return ['-c:a', 'flac'];
  if (codec === 'pcm') return ['-c:a', 'pcm_s24le'];
  if (codec === 'opus') return ['-c:a', 'libopus', '-b:a', a.bitrate + 'k'];
  return ['-c:a', 'aac', '-b:a', a.bitrate + 'k'];
}

// c: {s, caps, enc, variant, codec, geo, monIdx, audio:[{name,port,gain}], cam:{input:[]}|null, out, wavBase, testSrc}
function buildMain(c) {
  const s = c.s, v = s.video, A = ['-hide_banner', '-y', '-loglevel', 'info'];
  c.audio.forEach(a => A.push(...audioIn(a.port)));
  const vIdx = c.audio.length, vi = videoInput(c);
  A.push(...vi.input);
  let camIdx = -1; if (c.cam) { camIdx = vIdx + 1; A.push(...c.cam.input); }
  const br = v.bitrate || autoBitrate(c.geo.w, c.geo.h, v.fps);
  const p = { bitrate: br, mode: v.rate, cq: v.cq, quality: v.quality, fps: v.fps };
  A.push('-map', vIdx + ':v'); c.audio.forEach((a, i) => A.push('-map', i + ':a')); if (camIdx >= 0) A.push('-map', camIdx + ':v');
  if (c.testSrc) A.push(...encArgs('cpu', 'h264', { ...p, quality: 'speed' }, 0), '-pix_fmt:v:0', 'yuv420p');
  else A.push(...encArgs(c.enc, c.codec, p, 0, c.caps));
  if (vi.vf) A.push('-filter:v:0', vi.vf);
  A.push(...COLOR, '-fps_mode:v:0', 'cfr');
  if (camIdx >= 0) {
    const w = s.webcam, cp = { bitrate: w.bitrate, mode: 'vbr', cq: 20, quality: 'balanced', fps: w.fps };
    if (c.testSrc) A.push(...encArgs('cpu', 'h264', cp, 1), '-pix_fmt:v:1', 'yuv420p');
    else A.push(...encArgs(c.enc, 'h264', cp, 1, c.caps), '-pix_fmt:v:1', c.enc === 'cpu' ? 'yuv420p' : 'nv12');
    if (w.mirror) A.push('-filter:v:1', 'hflip');
    A.push('-metadata:s:v:1', 'title=Webcam');
  }
  A.push('-metadata:s:v:0', 'title=Screen');
  A.push(...audioCodecArgs(s.audio, 'mkv'), '-ar', '48000');
  c.audio.forEach((a, i) => { A.push('-metadata:s:a:' + i, 'title=' + a.name); if (a.gain) A.push('-filter:a:' + i, 'volume=' + a.gain + 'dB'); });
  A.push('-f', 'matroska', c.out);
  if (c.wavBase) c.audio.forEach((a, i) => {
    A.push('-map', i + ':a', ...(s.audio.wavFormat === 'flac' ? ['-c:a', 'flac'] : ['-c:a', 'pcm_s24le']));
    if (a.gain) A.push('-filter:a', 'volume=' + a.gain + 'dB');
    A.push(c.wavBase(i, a.name, s.audio.wavFormat === 'flac' ? 'flac' : 'wav'));
  });
  return A;
}

function camInput(w, test) {
  if (test) return ['-re', '-readrate_initial_burst', '0', '-f', 'lavfi', '-i', test];
  const a = ['-f', 'dshow', '-rtbufsize', '256M'];
  if (w.size) a.push('-video_size', w.size);
  if (w.fps) a.push('-framerate', String(w.fps));
  if (w.format && w.format !== 'auto') a.push(...(['mjpeg', 'h264'].includes(w.format) ? ['-vcodec', w.format] : ['-pixel_format', w.format]));
  a.push('-i', 'video=' + w.device);
  return a;
}

// c: {s, caps, enc, camInput, mic:{port}|null, out, testSrc}
function buildCam(c) {
  const w = c.s.webcam, A = ['-hide_banner', '-y', '-loglevel', 'info'];
  if (c.mic) A.push(...audioIn(c.mic.port));
  A.push(...c.camInput);
  const vi = c.mic ? 1 : 0;
  A.push('-map', vi + ':v'); if (c.mic) A.push('-map', '0:a');
  if (w.codec === 'copy' && ['h264', 'mjpeg'].includes(w.format) && !w.mirror && !c.testSrc) A.push('-c:v', 'copy');
  else {
    if (w.mirror) A.push('-vf', 'hflip');
    const p = { bitrate: w.bitrate, mode: 'vbr', cq: 20, quality: 'balanced', fps: w.fps };
    const enc = c.testSrc ? 'cpu' : c.enc;
    A.push(...encArgs(enc, 'h264', p, 0, c.caps), '-pix_fmt:v:0', enc === 'cpu' ? 'yuv420p' : 'nv12');
    A.push(...COLOR, '-fps_mode', 'cfr');
  }
  if (c.mic) A.push('-c:a', 'aac', '-b:a', '192k', '-ar', '48000', '-metadata:s:a:0', 'title=Mic');
  A.push('-f', 'matroska', c.out);
  return A;
}

// ---------- парсеры ----------
function parseDshowDevices(t) {
  const out = { video: [], audio: [] }; let sec = '';
  for (const ln of String(t).split(/\r?\n/)) {
    if (/DirectShow video devices/i.test(ln)) sec = 'video'; else if (/DirectShow audio devices/i.test(ln)) sec = 'audio';
    if (/Alternative name/i.test(ln)) continue;
    const m = ln.match(/"([^"]+)"(?:\s+\((video|audio|none)\))?/); if (!m) continue;
    const kind = m[2] || sec; if ((kind === 'video' || kind === 'audio') && !out[kind].includes(m[1])) out[kind].push(m[1]);
  }
  return out;
}
function parseDshowOptions(t) {
  const res = {}, fpsAll = [5, 10, 15, 20, 24, 25, 30, 48, 50, 60, 90, 120];
  const re = /(pixel_format|vcodec)=(\w+)\s+min s=(\d+)x(\d+) fps=([\d.]+) max s=(\d+)x(\d+) fps=([\d.]+)/g; let m;
  while ((m = re.exec(String(t)))) {
    const f = res[m[2]] || (res[m[2]] = {}), size = m[6] + 'x' + m[7], lo = parseFloat(m[5]), hi = parseFloat(m[8]);
    const set = f[size] || (f[size] = new Set());
    fpsAll.filter(x => x >= Math.floor(lo) && x <= Math.ceil(hi)).forEach(x => set.add(x)); set.add(Math.round(hi));
  }
  const out = [];
  for (const fmt of Object.keys(res)) out.push({ format: fmt, sizes: Object.keys(res[fmt]).sort((a, b) => parseInt(b) - parseInt(a)).map(sz => ({ size: sz, fps: [...res[fmt][sz]].sort((a, b) => a - b) })) });
  return out;
}
function parseStats(line) {
  const m = String(line).match(/frame=\s*(\d+)\s+fps=\s*([\d.]+).*?time=(\S+).*?speed=\s*([\d.]+)x/);
  if (!m) return null; const d = String(line).match(/drop=\s*(\d+)/);
  return { frame: +m[1], fps: +m[2], time: m[3], speed: +m[4], drop: d ? +d[1] : 0 };
}
function parseRes(t) { const m = String(t).match(/Video: [^\n]*?(\d{3,5})x(\d{3,5})/); return m ? { w: +m[1], h: +m[2] } : null; }
const asArray = x => x == null ? [] : Array.isArray(x) ? x : [x];
function stamp(d) { const p = n => String(n).padStart(2, '0'); d = d || new Date(); return `${d.getFullYear()}-${p(d.getMonth() + 1)}-${p(d.getDate())} ${p(d.getHours())}-${p(d.getMinutes())}-${p(d.getSeconds())}`; }

// ---------- питатель дорожки: непрерывный поток float32 в реальном времени ----------
class Feeder {
  constructor(name) {
    this.name = name; this.sinks = []; this.q = []; this.qf = 0; this.sent = 0; this.active = false;
    this.t0 = 0n; this.timer = null; this.skip = 0; this.peak = 0; this.carry = null;
    this.delay = Math.round(RATE * 0.03); this.stats = { silent: 0, dropped: 0, gaps: 0, resync: 0 };
  }
  push(buf) {
    if (this.carry) { buf = Buffer.concat([this.carry, buf]); this.carry = null; }
    const rem = buf.length % BPF;
    if (rem) { this.carry = Buffer.from(buf.subarray(buf.length - rem)); buf = buf.subarray(0, buf.length - rem); }
    if (!buf.length) return;
    let pk = 0;
    for (let i = 0; i + 8 <= buf.length; i += 32) { const a = Math.abs(buf.readFloatLE(i)), b = Math.abs(buf.readFloatLE(i + 4)); if (a > pk) pk = a; if (b > pk) pk = b; }
    if (pk > this.peak) this.peak = pk;
    if (!this.active) return;
    let frames = buf.length / BPF;
    if (this.skip > 0) { const d = Math.min(this.skip, frames); this.skip -= d; buf = buf.subarray(d * BPF); frames -= d; if (!frames) return; }
    const now = Number(process.hrtime.bigint() - this.t0) / 1e9, arr = Math.round(now * RATE) - frames, gap = arr - (this.sent + this.qf);
    if (gap > RATE * 0.06) { this.q.push(Buffer.alloc(gap * BPF)); this.qf += gap; this.stats.gaps++; }
    else if (gap < -RATE * 0.1) {
      const drop = Math.min(frames, -gap - Math.round(RATE * 0.03));
      if (drop > 0) { buf = buf.subarray(drop * BPF); frames -= drop; this.stats.resync++; if (!frames) return; }
    }
    this.q.push(buf); this.qf += frames;
  }
  takeLevel() { const p = this.peak; this.peak = 0; return p; }
  addSink(sock) {
    sock.write(Buffer.alloc(PRIMER * BPF)); // «затравка»: без неё ffmpeg зависает при открытии входа
    this.sinks.push(sock);
    const rm = () => { const i = this.sinks.indexOf(sock); if (i >= 0) this.sinks.splice(i, 1); };
    sock.on('close', rm); sock.on('error', rm);
  }
  go(t0, offsetMs) {
    if (this.timer) clearInterval(this.timer);
    this.delay = Math.round(RATE * 0.03);
    this.stats = { silent: 0, dropped: 0, gaps: 0, resync: 0 };
    this.t0 = t0; this.active = true; this.sent = PRIMER; this.q = []; this.qf = 0; this.skip = 0;
    const adj = Math.round((offsetMs || 0) * RATE / 1000) - PRIMER;
    if (adj > 0) { this.q.push(Buffer.alloc(adj * BPF)); this.qf += adj; } else this.skip = -adj;
    this.timer = setInterval(() => this.tick(), 10);
  }
  tick() {
    const target = Math.floor(Number(process.hrtime.bigint() - this.t0) / 1e9 * RATE) - this.delay;
    let need = target - this.sent; if (need <= 0) return; if (need > RATE) need = RATE;
    const out = Buffer.allocUnsafe(need * BPF); let off = 0, left = need;
    while (left > 0 && this.q.length) {
      const b = this.q[0], bf = b.length / BPF;
      if (bf <= left) { b.copy(out, off); off += b.length; left -= bf; this.q.shift(); }
      else { b.copy(out, off, 0, left * BPF); this.q[0] = b.subarray(left * BPF); off += left * BPF; left = 0; }
    }
    this.qf -= need - left;
    if (left > 0) { out.fill(0, off); this.stats.silent += left; }
    this.sent += need;
    for (const s of this.sinks) { if (!s.writable) continue; if (s.writableLength > 8 << 20) { this.stats.dropped += need; continue; } s.write(out); }
  }
  finish() {
    if (this.timer) { clearInterval(this.timer); this.timer = null; }
    if (this.active) { this.delay = 0; this.tick(); }
    this.active = false; this.q = []; this.qf = 0;
    for (const s of this.sinks.splice(0)) { try { s.end(); } catch (e) {} }
  }
  clearSinks() { for (const s of this.sinks.splice(0)) { try { s.destroy(); } catch (e) {} } }
}

module.exports = { RATE, BPF, PRIMER, ENC_NAME, defaults, deepMerge, sanitize, trackActive, autoBitrate, geometry, encArgs, nvencSpatialOption, variantsFor,
  buildMain, buildCam, camInput, audioCodecArgs, parseDshowDevices, parseDshowOptions, parseStats, parseRes, asArray, stamp, safe, Feeder };
