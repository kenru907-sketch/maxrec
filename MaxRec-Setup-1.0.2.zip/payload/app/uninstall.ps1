﻿Add-Type -AssemblyName System.Windows.Forms
$Root = Split-Path -Parent $PSScriptRoot
$a = [System.Windows.Forms.MessageBox]::Show('Удалить MaxRec с этого компьютера?' + "`n`n" + 'Ваши видеозаписи не затрагиваются.', 'MaxRec', 'YesNo', 'Question')
if ($a -ne 'Yes') { exit }
try { Get-Process -Name node -ErrorAction SilentlyContinue | Where-Object { $_.Path -and $_.Path.StartsWith($Root, [StringComparison]::OrdinalIgnoreCase) } | Stop-Process -Force -ErrorAction SilentlyContinue } catch {}
Remove-Item (Join-Path ([Environment]::GetFolderPath('Desktop')) 'MaxRec.lnk') -Force -ErrorAction SilentlyContinue
Remove-Item (Join-Path ([Environment]::GetFolderPath('Programs')) 'MaxRec.lnk') -Force -ErrorAction SilentlyContinue
Remove-Item 'HKCU:\Software\Microsoft\Windows\CurrentVersion\Uninstall\MaxRec' -Recurse -Force -ErrorAction SilentlyContinue
$data = Join-Path $env:APPDATA 'MaxRec'
if (Test-Path $data) {
  $b = [System.Windows.Forms.MessageBox]::Show('Удалить также настройки и журналы MaxRec?', 'MaxRec', 'YesNo', 'Question')
  if ($b -eq 'Yes') { Remove-Item $data -Recurse -Force -ErrorAction SilentlyContinue }
}
Start-Process -FilePath 'cmd.exe' -ArgumentList ('/c ping 127.0.0.1 -n 3 >nul & rmdir /s /q "' + $Root + '"') -WindowStyle Hidden
