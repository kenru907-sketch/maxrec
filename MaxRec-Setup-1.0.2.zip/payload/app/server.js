'use strict';
// MaxRec — сервер: управляет ffmpeg, аудио-модулем, горячими клавишами и отдаёт интерфейс.
const http = require('http'), net = require('net'), fs = require('fs'), path = require('path'), os = require('os');
const cp = require('child_process'), https = require('https'), crypto = require('crypto');
const { pipeline } = require('node:stream/promises');
const core = require('./core');

const IS_WIN = process.platform === 'win32';
const APP_DIR = __dirname;
const ROOT = process.env.MAXREC_ROOT || path.resolve(APP_DIR, '..');
const DATA = process.env.MAXREC_DATA || path.join(process.env.APPDATA || path.join(os.homedir(), '.config'), 'MaxRec');
const BIN = path.join(ROOT, 'bin');
const TEST = !!process.env.MAXREC_TEST;
const FFMPEG = process.env.MAXREC_FFMPEG || path.join(BIN, IS_WIN ? 'ffmpeg.exe' : 'ffmpeg');
const HELPER = process.env.MAXREC_HELPER || path.join(BIN, 'maxhelper.exe');
const NAME = 'MaxRec', VERSION = '1.0.2';
const START = Date.now();

fs.mkdirSync(path.join(DATA, 'logs'), { recursive: true });
const LOGF = path.join(DATA, 'logs', 'app.log');
try { if (fs.statSync(LOGF).size > 2e6) fs.renameSync(LOGF, LOGF + '.old'); } catch (e) {}
function log(...a) {
  const line = new Date().toISOString().slice(11, 23) + ' ' + a.map(x => typeof x === 'string' ? x : (x instanceof Error ? x.stack : JSON.stringify(x))).join(' ');
  try { fs.appendFileSync(LOGF, line + '\n'); } catch (e) {}
  if (TEST || process.env.MAXREC_VERBOSE) console.log(line);
}
process.on('uncaughtException', e => log('UNCAUGHT', e));
process.on('unhandledRejection', e => log('UNHANDLED', e));

const sleep = ms => new Promise(r => setTimeout(r, ms));
const mb = n => Math.round(n / 1048576) + ' МБ';
const safeJson = s => { try { return JSON.parse(s); } catch (e) { return null; } };

function run(cmd, args, opt) {
  opt = opt || {};
  return new Promise(res => {
    let out = '', err = '', done = false, p, tm = null;
    const fin = code => { if (done) return; done = true; if (tm) clearTimeout(tm); res({ code, out, err }); };
    try { p = cp.spawn(cmd, args, { windowsHide: true, stdio: ['ignore', 'pipe', 'pipe'] }); } catch (e) { return res({ code: -1, out: '', err: String(e) }); }
    if (opt.timeout) tm = setTimeout(() => { try { p.kill(); } catch (e) {} fin(-2); }, opt.timeout);
    p.stdout.setEncoding('utf8').on('data', d => out += d); p.stderr.setEncoding('utf8').on('data', d => err += d);
    p.on('error', e => { err += String(e); fin(-1); }); p.on('close', c => fin(c));
  });
}
const ps = (script, timeout) => run('powershell', ['-NoProfile', '-NonInteractive', '-ExecutionPolicy', 'Bypass', '-Command', '[Console]::OutputEncoding=[System.Text.Encoding]::UTF8; ' + script], { timeout: timeout || 15000 });
function killTree(p) { try { if (IS_WIN) cp.spawn('taskkill', ['/PID', String(p.pid), '/T', '/F'], { windowsHide: true, stdio: 'ignore' }); else p.kill('SIGKILL'); } catch (e) {} }

// ---------------- настройки и состояние ----------------
const SETF = path.join(DATA, 'settings.json');
const DEF = core.defaults(path.join(process.env.USERPROFILE || os.homedir(), 'Videos'));
function loadSettings() {
  let s = DEF; try { s = core.deepMerge(DEF, JSON.parse(fs.readFileSync(SETF, 'utf8'))); } catch (e) {}
  return core.sanitize(JSON.parse(JSON.stringify(s)), DEF);
}
const ST = {
  settings: loadSettings(),
  caps: { version: '', ddagrab: false, enc: {}, probed: false },
  ready: { ffmpeg: false, helper: false },
  setup: { running: false, step: '', pct: 0, error: '', needed: false },
  dev: { render: [], capture: [], monitors: [], cams: [] },
  rec: { state: 'idle', startedAt: 0, files: [], error: '', info: '', stats: null, audio: {} },
  hotkey: { ok: false, err: '' },
  monitoring: false,
};
const TRACKS = Object.create(null);
function saveSettings() { try { fs.writeFileSync(SETF, JSON.stringify(ST.settings, null, 1)); } catch (e) { log('save settings', e); } }

const clients = new Set();
const sse = (res, ev, data) => { try { res.write('event: ' + ev + '\ndata: ' + JSON.stringify(data) + '\n\n'); } catch (e) {} };
function publicState() {
  return { name: NAME, version: VERSION, platform: process.platform, test: TEST, settings: ST.settings, caps: ST.caps, ready: ST.ready, setup: ST.setup, dev: ST.dev, rec: ST.rec,
    tracks: Object.keys(TRACKS).map(k => ({ id: k, status: TRACKS[k].status, detail: TRACKS[k].detail })), hotkey: ST.hotkey, monitoring: ST.monitoring, now: Date.now() };
}
let stT = null;
function emitState() { if (stT) return; stT = setTimeout(() => { stT = null; const s = publicState(); for (const c of clients) sse(c, 'state', s); }, 40); }
function toast(kind, msg) { log('TOAST', kind, msg); for (const c of clients) sse(c, 'toast', { kind, msg }); }
function step(msg, pct) { ST.setup.step = msg; if (pct != null) ST.setup.pct = pct; emitState(); }

// ---------------- скачивание, распаковка, сборка ----------------
function download(url, dest, onProgress, redirects) {
  redirects = redirects || 0;
  return new Promise((resolve, reject) => {
    if (new URL(url).protocol !== 'https:') return reject(new Error('Для загрузки FFmpeg нужен HTTPS'));
    const req = https.get(url, { headers: { 'User-Agent': 'MaxRec/' + VERSION } }, res => {
      if (res.statusCode >= 300 && res.statusCode < 400 && res.headers.location) {
        res.resume(); if (redirects > 8) return reject(new Error('слишком много перенаправлений'));
        return resolve(download(new URL(res.headers.location, url).toString(), dest, onProgress, redirects + 1));
      }
      if (res.statusCode !== 200) { res.resume(); return reject(new Error('HTTP ' + res.statusCode)); }
      const total = parseInt(res.headers['content-length'] || '0', 10); let got = 0;
      const out = fs.createWriteStream(dest);
      res.on('data', d => { got += d.length; if (onProgress) onProgress(got, total); });
      pipeline(res, out).then(() => {
        if (total && got !== total) reject(new Error('Загрузка FFmpeg оборвалась')); else resolve();
      }, reject);
    });
    req.on('error', reject); req.setTimeout(30000, () => req.destroy(new Error('нет ответа от сервера')));
  });
}
async function extractZip(zip, dest) {
  fs.mkdirSync(dest, { recursive: true });
  if (IS_WIN) {
    const tar = path.join(process.env.SystemRoot || 'C:\\Windows', 'System32', 'tar.exe');
    let r = fs.existsSync(tar) ? await run(tar, ['-xf', zip, '-C', dest]) : { code: -1 };
    if (r.code === 0) return;
    const q = s => s.replace(/'/g, "''");
    r = await ps(`Expand-Archive -LiteralPath '${q(zip)}' -DestinationPath '${q(dest)}' -Force`, 300000);
    if (r.code !== 0) throw new Error('не удалось распаковать архив: ' + (r.err || r.out).slice(0, 200));
  } else {
    const r = await run('unzip', ['-q', '-o', zip, '-d', dest]);
    if (r.code !== 0) throw new Error('не удалось распаковать архив: ' + r.err.slice(0, 200));
  }
}
function findFile(dir, name) {
  for (const e of fs.readdirSync(dir, { withFileTypes: true })) {
    const p = path.join(dir, e.name);
    if (e.isDirectory()) { const r = findFile(p, name); if (r) return r; } else if (e.name.toLowerCase() === name.toLowerCase()) return p;
  }
  return '';
}
const FF_URLS = ['https://github.com/BtbN/FFmpeg-Builds/releases/download/latest/ffmpeg-master-latest-win64-gpl.zip', 'https://www.gyan.dev/ffmpeg/builds/ffmpeg-release-essentials.zip'];
async function installFfmpeg() {
  fs.mkdirSync(path.dirname(FFMPEG), { recursive: true });
  const urls = process.env.MAXREC_FF_URL ? [process.env.MAXREC_FF_URL] : FF_URLS; let lastErr = '';
  for (let i = 0; i < urls.length; i++) {
    const work = fs.mkdtempSync(path.join(os.tmpdir(), 'maxrec-ffmpeg-'));
    const tmp = path.join(work, 'ffmpeg.zip'), dir = path.join(work, 'extracted');
    try {
      step('Скачиваю FFmpeg…' + (i ? ' (запасной источник)' : ''), 3);
      await download(urls[i], tmp, (got, total) => {
        ST.setup.pct = Math.max(ST.setup.pct, 3 + Math.round(52 * (total ? got / total : Math.min(0.9, got / 150e6))));
        ST.setup.step = 'Скачиваю FFmpeg… ' + mb(got) + (total ? ' из ' + mb(total) : ''); emitState();
      });
      step('Распаковываю…', 58);
      await extractZip(tmp, dir);
      const exe = findFile(dir, IS_WIN ? 'ffmpeg.exe' : 'ffmpeg'); if (!exe) throw new Error('в архиве нет ffmpeg');
      await validateFfmpeg(exe);
      fs.copyFileSync(exe, FFMPEG);
      try { const pr = findFile(dir, IS_WIN ? 'ffprobe.exe' : 'ffprobe'); if (pr) fs.copyFileSync(pr, path.join(path.dirname(FFMPEG), path.basename(pr))); } catch (e) { log('ffprobe copy', e); }
      return;
    } catch (e) { lastErr = String(e.message || e); log('ffmpeg download failed', urls[i], lastErr); }
    finally { try { fs.rmSync(work, { recursive: true, force: true }); } catch (e) { log('cleanup FFmpeg', e); } }
  }
  throw new Error('Не удалось скачать FFmpeg (' + lastErr + '). Проверьте интернет и нажмите «Повторить».');
}
async function validateFfmpeg(p) {
  const r = await run(p, ['-version'], { timeout: 10000 });
  if (r.code !== 0 || !/^ffmpeg version /i.test(r.out)) throw new Error('Не удалось запустить FFmpeg. Проверьте файл, версию и разрядность.');
}
async function useLocalFfmpeg(p) {
  if (typeof p !== 'string' || !path.isAbsolute(p) || !fs.statSync(p, { throwIfNoEntry: false })?.isFile()) throw new Error('Укажите полный путь к файлу FFmpeg');
  await validateFfmpeg(p);
  fs.mkdirSync(path.dirname(FFMPEG), { recursive: true });
  if (path.relative(p, FFMPEG)) fs.copyFileSync(p, FFMPEG);
}
const helperSrc = () => path.join(APP_DIR, 'helper', 'maxhelper.cs');
const srcHash = () => { try { return crypto.createHash('sha1').update(fs.readFileSync(helperSrc())).digest('hex'); } catch (e) { return ''; } };
const hashFile = () => path.join(BIN, 'maxhelper.hash');
function helperUpToDate() {
  if (process.env.MAXREC_HELPER) return fs.existsSync(HELPER);
  try { return fs.existsSync(HELPER) && fs.readFileSync(hashFile(), 'utf8') === srcHash(); } catch (e) { return false; }
}
function findCsc() {
  const w = process.env.SystemRoot || 'C:\\Windows';
  return [path.join(w, 'Microsoft.NET', 'Framework64', 'v4.0.30319', 'csc.exe'), path.join(w, 'Microsoft.NET', 'Framework', 'v4.0.30319', 'csc.exe')].find(p => fs.existsSync(p)) || '';
}
async function ensureHelper() {
  if (helperUpToDate()) return;
  const csc = findCsc(); if (!csc) throw new Error('Не найден компилятор C# (csc.exe) — нужен .NET Framework 4.x');
  fs.mkdirSync(BIN, { recursive: true });
  const r = await run(csc, ['/nologo', '/target:exe', '/platform:anycpu', '/optimize+', '/unsafe', '/out:' + HELPER, '/r:System.dll', '/r:System.Core.dll', helperSrc()], { timeout: 120000 });
  const text = (r.out + r.err).trim();
  fs.writeFileSync(path.join(DATA, 'logs', 'csc.log'), text);
  if (r.code !== 0 || !fs.existsSync(HELPER)) throw new Error('Сборка аудио-модуля не удалась. ' + text.split('\n').slice(0, 3).join(' | ').slice(0, 400));
  fs.writeFileSync(hashFile(), srcHash());
}
function helperSpawn(args) {
  const js = HELPER.endsWith('.js');
  return { cmd: js ? process.execPath : HELPER, args: js ? [HELPER].concat(args) : args };
}

// ---------------- возможности FFmpeg, устройства ----------------
async function probeCaps(force) {
  const capF = path.join(DATA, 'caps.json'); let st; try { st = fs.statSync(FFMPEG); } catch (e) { return; }
  const key = 'ffmpeg-caps-2:' + st.size + ':' + Math.round(st.mtimeMs);
  if (!force) { const c = safeJson((() => { try { return fs.readFileSync(capF, 'utf8'); } catch (e) { return ''; } })()); if (c && c.key === key && c.caps) { ST.caps = c.caps; emitState(); return; } }
  step('Проверяю возможности FFmpeg…', 80);
  const caps = { version: '', ddagrab: false, enc: {}, nvencSpatial: {}, probed: true };
  const v = await run(FFMPEG, ['-hide_banner', '-version'], { timeout: 10000 });
  if (v.code !== 0 || !/^ffmpeg version /i.test(v.out)) {
    ST.ready.ffmpeg = false;
    throw new Error('Установленный FFmpeg не запускается. Укажите другой ffmpeg.exe или нажмите «Повторить».');
  }
  caps.version = (v.out.split('\n')[0] || '').slice(0, 90);
  const e = await run(FFMPEG, ['-hide_banner', '-encoders'], { timeout: 15000 }); const listed = new Set();
  for (const m of e.out.matchAll(/^\s*V\S*\s+(\S+)/gm)) listed.add(m[1]);
  const f = await run(FFMPEG, ['-hide_banner', '-filters'], { timeout: 15000 }); caps.ddagrab = /\bddagrab\b/.test(f.out);
  for (const fam of ['nvenc', 'amf', 'qsv', 'cpu']) {
    caps.enc[fam] = {};
    for (const codec of ['h264', 'hevc', 'av1']) {
      const name = core.ENC_NAME[fam][codec];
      if (!listed.has(name)) { caps.enc[fam][codec] = false; continue; }
      if (fam === 'cpu') { caps.enc[fam][codec] = true; continue; }
      step('Проверяю кодер ' + name + '…');
      if (fam === 'nvenc') {
        const help = await run(FFMPEG, ['-hide_banner', '-h', 'encoder=' + name], { timeout: 5000 });
        caps.nvencSpatial[codec] = core.nvencSpatialOption(help.out + '\n' + help.err);
      }
      const p = { bitrate: 8, mode: 'vbr', cq: 20, quality: 'balanced', fps: 30 };
      const t = await run(FFMPEG, ['-hide_banner', '-loglevel', 'error', '-f', 'lavfi', '-i', 'color=c=black:s=1280x720:r=30', '-frames:v', '6', ...core.encArgs(fam, codec, p, 0, caps), '-f', 'null', '-'], { timeout: 15000 });
      caps.enc[fam][codec] = t.code === 0;
      if (t.code !== 0) log('encoder probe failed', name, (t.err || t.out).trim().slice(-500));
    }
  }
  ST.caps = caps; try { fs.writeFileSync(capF, JSON.stringify({ key, caps })); } catch (e2) {}
  emitState();
}
async function probeMonitors() {
  if (TEST) { ST.dev.monitors = [{ idx: 0, w: 1280, h: 720, name: 'Экран 1' }]; return; }
  const out = [];
  if (ST.caps.ddagrab) for (let i = 0; i < 6; i++) {
    const r = await run(FFMPEG, ['-hide_banner', '-f', 'lavfi', '-i', `ddagrab=output_idx=${i}:framerate=5`, '-frames:v', '1', '-f', 'null', '-'], { timeout: 8000 });
    const res = core.parseRes(r.err); if (r.code !== 0 || !res) break; out.push({ idx: i, w: res.w, h: res.h });
  }
  if (!out.length) out.push({ idx: 0, w: 1920, h: 1080, guess: true });
  out.forEach((m, i) => { m.name = 'Экран ' + (i + 1); });
  ST.dev.monitors = out;
}
async function refreshCams() {
  if (TEST) { ST.dev.cams = (process.env.MAXREC_TEST_CAMS || 'Тестовая камера').split('|'); return; }
  if (!IS_WIN || !ST.ready.ffmpeg) { ST.dev.cams = []; return; }
  const r = await run(FFMPEG, ['-hide_banner', '-list_devices', 'true', '-f', 'dshow', '-i', 'dummy'], { timeout: 10000 });
  ST.dev.cams = core.parseDshowDevices(r.err).video;
}
async function discover() {
  if (ST.ready.helper) {
    const h = helperSpawn(['list']); const r = await run(h.cmd, h.args, { timeout: 12000 }); const j = safeJson(r.out);
    if (j) { ST.dev.render = j.render || []; ST.dev.capture = j.capture || []; } else log('helper list failed', r.out.slice(0, 200), r.err.slice(0, 200));
  }
  await refreshCams(); await probeMonitors(); emitState();
}
async function camOptions(device) {
  if (TEST) return [{ format: 'mjpeg', sizes: [{ size: '1920x1080', fps: [30, 60] }, { size: '1280x720', fps: [30, 60] }] }, { format: 'yuyv422', sizes: [{ size: '640x480', fps: [30] }] }];
  const r = await run(FFMPEG, ['-hide_banner', '-f', 'dshow', '-list_options', 'true', '-i', 'video=' + device], { timeout: 12000 });
  return core.parseDshowOptions(r.err);
}
async function listApps() {
  if (TEST) return safeJson(process.env.MAXREC_TEST_APPS || '') || [{ exe: 'TestGame.exe', title: 'Test Game' }, { exe: 'Discord.exe', title: 'Discord' }];
  const r = await ps("Get-Process | Where-Object { $_.MainWindowHandle -ne 0 -and $_.MainWindowTitle } | Select-Object @{n='exe';e={$_.ProcessName + '.exe'}}, @{n='title';e={$_.MainWindowTitle}} | ConvertTo-Json -Compress");
  const seen = new Map();
  for (const x of core.asArray(safeJson(r.out))) if (x && x.exe && !/^(node|powershell|conhost)\.exe$/i.test(x.exe) && !seen.has(x.exe.toLowerCase())) seen.set(x.exe.toLowerCase(), { exe: x.exe, title: x.title });
  return [...seen.values()].sort((a, b) => a.exe.localeCompare(b.exe));
}
const rootCache = new Map();
async function pidAlive(pid) {
  if (TEST) return true;
  const r = await run('tasklist', ['/FI', 'PID eq ' + pid, '/FO', 'CSV', '/NH'], { timeout: 6000 });
  return r.out.includes('"' + pid + '"');
}
// Корневой процесс приложения (для Discord и подобных — главный, у которого родитель не того же приложения)
async function resolveRoot(exe) {
  if (TEST) return 4242;
  const key = exe.toLowerCase(), c = rootCache.get(key);
  if (c && (await pidAlive(c))) return c;
  rootCache.delete(key);
  const r = await run('tasklist', ['/FI', 'IMAGENAME eq ' + exe, '/FO', 'CSV', '/NH'], { timeout: 8000 });
  const pids = []; for (const m of r.out.matchAll(/^"[^"]*","(\d+)"/gm)) pids.push(Number(m[1]));
  if (!pids.length) return 0;
  let pid = pids[0];
  if (pids.length > 1) {
    const q = await ps(`Get-CimInstance Win32_Process -Filter "Name='${exe}'" | Select-Object ProcessId,ParentProcessId | ConvertTo-Json -Compress`);
    const a = core.asArray(safeJson(q.out));
    if (a.length) { const ids = new Set(a.map(x => x.ProcessId)), roots = a.filter(x => !ids.has(x.ParentProcessId)); pid = (roots[0] || a[0]).ProcessId; }
  }
  rootCache.set(key, pid); return pid;
}
function prewarmRoots() { ST.settings.audio.tracks.filter(core.trackActive).forEach(t => { if (t.type === 'app' || t.type === 'except') resolveRoot(t.exe).catch(() => {}); }); }

// ---------------- звуковые дорожки ----------------
class Track {
  constructor(cfg) { this.cfg = cfg; this.id = cfg.id; this.sig = trackSig(cfg); this.feeder = new core.Feeder(cfg.name); this.proc = null; this.status = 'init'; this.detail = ''; this.stopped = false; this.timer = null; }
  start() { this.stopped = false; this.launch(); }
  async launch() {
    if (this.stopped || this.proc) return;
    const c = this.cfg; const a = ['capture'];
    try {
      if (c.type === 'system' || c.type === 'mic') { a.push('--kind', c.type); if (c.device) a.push('--device', c.device); }
      else {
        const pid = await resolveRoot(c.exe); if (this.stopped) return;
        if (pid) a.push('--kind', c.type, '--pid', String(pid));
        else if (c.type === 'except') { this.status = 'waiting'; this.detail = 'ждёт запуска ' + c.exe + ' — до этого дорожка без звука'; emitState(); return this.retry(3000); }
        else { this.status = 'waiting'; this.detail = 'ждёт запуска ' + c.exe; emitState(); return this.retry(3000); }
      }
      this.spawn(a);
    } catch (e) { this.status = 'error'; this.detail = String(e.message || e); emitState(); this.retry(4000); }
  }
  retry(ms) { clearTimeout(this.timer); this.timer = setTimeout(() => { if (!this.stopped && !this.proc) this.launch(); }, ms); }
  spawn(args) {
    const h = helperSpawn(args); let p;
    try { p = cp.spawn(h.cmd, h.args, { windowsHide: true, stdio: ['pipe', 'pipe', 'pipe'] }); } catch (e) { this.status = 'error'; this.detail = String(e.message || e); emitState(); return this.retry(4000); }
    this.proc = p; this.status = 'starting'; let eb = '';
    p.stdin.on('error', () => {}); p.stdout.on('data', d => this.feeder.push(d));
    p.stderr.on('data', d => { eb += d.toString('utf8'); let i; while ((i = eb.indexOf('\n')) >= 0) { this.line(eb.slice(0, i).trim()); eb = eb.slice(i + 1); } });
    p.on('error', e => { this.status = 'error'; this.detail = String(e.message || e); emitState(); });
    p.on('close', code => { if (this.proc !== p) return; this.proc = null; if (!this.stopped) { if (this.status !== 'error') { this.status = 'error'; this.detail = 'аудио-модуль остановился (' + code + ')'; } emitState(); this.retry(2500); } });
  }
  line(l) {
    if (!l) return; log('helper[' + this.id + ']', l);
    if (l.startsWith('READY')) { this.status = 'ok'; this.detail = l.slice(6); }
    else if (l.startsWith('ERR')) { this.status = 'error'; this.detail = l.slice(4); }
    emitState();
  }
  stop() { this.stopped = true; clearTimeout(this.timer); if (this.proc) { try { this.proc.stdin.end(); this.proc.kill(); } catch (e) {} this.proc = null; } this.feeder.finish(); }
}
const trackSig = t => [t.type, t.exe, t.device].join('|');
function ensureTracks(settings = ST.settings) {
  const want = settings.audio.tracks.filter(core.trackActive), ids = new Set(want.map(t => t.id));
  for (const id of Object.keys(TRACKS)) if (!ids.has(id)) { TRACKS[id].stop(); delete TRACKS[id]; }
  for (const t of want) {
    const cur = TRACKS[t.id];
    if (cur && cur.sig === trackSig(t)) { cur.cfg = t; continue; }
    if (cur) cur.stop();
    TRACKS[t.id] = new Track(t); TRACKS[t.id].start();
  }
  emitState();
}
function stopAllTracks() { for (const id of Object.keys(TRACKS)) { TRACKS[id].stop(); delete TRACKS[id]; } emitState(); }
function setMonitor(on) { ST.monitoring = !!on; if (on && ST.rec.state === 'idle') ensureTracks(); else if (!on && ST.rec.state === 'idle') stopAllTracks(); emitState(); }
setInterval(() => {
  if (!clients.size || !(ST.monitoring || ST.rec.state === 'recording')) return;
  const L = {}; for (const id of Object.keys(TRACKS)) L[id] = +TRACKS[id].feeder.takeLevel().toFixed(4);
  for (const c of clients) sse(c, 'levels', L);
}, 66);

// ---------------- запись ----------------
let REC = null;
function mkSession(s) {
  const tag = core.stamp() + '-' + crypto.randomBytes(4).toString('hex');
  const dir = s.output.sessionFolder ? path.join(s.output.folder, tag) : s.output.folder;
  fs.mkdirSync(dir, { recursive: true });
  const nm = (suffix, ext) => path.join(dir, (s.output.sessionFolder ? '' : tag + ' ') + suffix + '.' + ext);
  // Номер дорожки предотвращает перезапись, даже если имена совпадают в Windows.
  return { dir, main: nm('Screen', 'mkv'), cam: nm('Webcam', 'mkv'), wav: (i, n, ext) => nm('Audio ' + (i + 1) + ' - ' + core.safe(n), ext) };
}
function listenOne(onSock) {
  return new Promise((resolve, reject) => {
    const srv = net.createServer(sock => { sock.setNoDelay(true); onSock(sock); srv.close(); });
    srv.on('error', reject); srv.listen(0, '127.0.0.1', () => resolve({ srv, port: srv.address().port }));
  });
}
let FLOG = null;
function launchFfmpeg(tag, args) {
  return new Promise(resolve => {
    let p; const o = { tag, ready: false, exited: false, code: null, tail: [], stats: null };
    o.exitP = new Promise(r => { o.exitRes = r; });
    try { p = cp.spawn(FFMPEG, args, { windowsHide: true, stdio: ['pipe', 'pipe', 'pipe'] }); } catch (e) { o.exited = true; o.tail.push(String(e)); o.exitRes(-1); return resolve(o); }
    o.p = p; let buf = '', settled = false; const settle = () => { if (!settled) { settled = true; clearTimeout(startTimeout); resolve(o); } };
    const startTimeout = setTimeout(settle, 12000);
    p.stderr.setEncoding('utf8').on('data', d => {
      buf += d; const parts = buf.split(/[\r\n]+/); buf = parts.pop();
      for (const ln of parts) {
        if (!ln) continue; const st = core.parseStats(ln); if (st) { o.stats = st; continue; }
        o.tail.push(ln); if (o.tail.length > 60) o.tail.shift();
        if (FLOG) FLOG.write('[' + tag + '] ' + ln + '\n');
        if (!o.ready && /Press \[q\] to stop/.test(ln)) { o.ready = true; settle(); }
        else if (!o.ready && /^Output #0/.test(ln)) setTimeout(() => { if (!o.ready && !o.exited) { o.ready = true; settle(); } }, 1800);
      }
    });
    p.stdout.on('data', () => {}); p.stdin.on('error', () => {});
    p.on('error', e => { o.exited = true; o.tail.push(String(e)); o.exitRes(-1); settle(); });
    p.on('close', c => { o.exited = true; o.code = c; o.exitRes(c); settle(); });
  });
}
const errLines = o => { const l = o.tail.filter(x => /rror|nvalid|ailed|Cannot|annot|nsupported|not found|No such|denied|Unrecognized|Unknown/i.test(x)); return (l.length ? l : o.tail).slice(-4).join(' | ').slice(0, 500); };

function buildAttempts(s, geo) {
  const first = resolveEncoder(s.video.encoder, s.video.codec), list = [];
  const add = (enc, codec) => core.variantsFor(enc, geo, ST.caps).forEach(variant => list.push({ enc, codec, variant }));
  add(first.enc, first.codec);
  if (first.enc !== 'cpu') add('cpu', ST.caps.enc.cpu && ST.caps.enc.cpu[first.codec] ? first.codec : 'h264');
  return list;
}
function resolveEncoder(pref, codec) {
  const E = ST.caps.enc || {}, ok = (f, c) => !!(E[f] && E[f][c]);
  for (const f of pref === 'auto' ? ['nvenc', 'amf', 'qsv', 'cpu'] : [pref, 'cpu']) if (ok(f, codec)) return { enc: f, codec };
  for (const f of ['nvenc', 'amf', 'qsv', 'cpu']) if (ok(f, 'h264')) return { enc: f, codec: 'h264' };
  return { enc: 'cpu', codec: 'h264' };
}
const camTest = () => TEST ? (process.env.MAXREC_TEST_CAM || 'testsrc2=size=640x360:rate=30') : '';

async function tryStart(s, session, at, tracks, geo, mon) {
  const servers = [], procs = [];
  const cleanup = async () => {
    servers.forEach(x => { try { x.srv.close(); } catch (e) {} });
    tracks.forEach(t => { t.feeder.clearSinks(); t.feeder.finish(); });
    const running = procs.filter(o => o.p && !o.exited);
    running.forEach(o => killTree(o.p));
    // Let the failed attempt release the DirectShow device before opening it again.
    if (running.length) await Promise.race([Promise.all(running.map(o => o.exitP)), sleep(2500)]);
  };
  try {
    const audio = [];
    for (const t of tracks) { const l = await listenOne(sock => t.feeder.addSink(sock)); servers.push(l); audio.push({ name: t.cfg.name, port: l.port, gain: t.cfg.gain }); }
    const w = s.webcam, camOn = w.mode !== 'off' && (w.device || TEST);
    const ctx = { s, caps: ST.caps, enc: at.enc, codec: at.codec, variant: at.variant, geo, monIdx: mon.idx, audio, out: session.main, testSrc: TEST ? (process.env.MAXREC_TEST_SRC || 'testsrc2=size=1280x720:rate=30') : '',
      cam: null, wavBase: s.audio.wav && audio.length ? session.wav : null };
    if (camOn && w.mode === 'track') ctx.cam = { input: core.camInput(w, camTest()) };
    let camArgs, camInput, mic;
    if (camOn && w.mode === 'file') {
      const micT = w.mic ? tracks.find(t => t.cfg.type === 'mic') : null;
      if (micT) { camInput = await listenOne(sock => micT.feeder.addSink(sock)); servers.push(camInput); mic = { port: camInput.port }; }
      camArgs = core.buildCam({ s, caps: ST.caps, enc: at.enc, camInput: core.camInput(w, camTest()), mic, out: session.cam, testSrc: TEST });
    }
    log('ffmpeg main attempt', at.enc, at.codec, at.variant);
    if (FLOG) FLOG.write('\n=== ' + [at.enc, at.codec, at.variant].join(' / ') + ' ===\n');
    const launch = (tag, args) => launchFfmpeg(tag, args).then(o => { procs.push(o); return o; });
    const mainP = launch('main', core.buildMain(ctx));
    const camP = camArgs ? launch('cam', camArgs) : null;
    const t0 = process.hrtime.bigint(), goAt = Date.now();
    tracks.forEach(t => t.feeder.go(t0, t.cfg.offset));
    let [main, cam] = await Promise.all([mainP, camP]);
    if (!main.ready || main.exited) throw new Error(errLines(main) || 'ffmpeg не запустился');
    if (cam && (!cam.ready || cam.exited)) {
      if (cam.p && !cam.exited) killTree(cam.p);
      if (camInput) camInput.srv.close();
      toast('warn', 'Веб-камера не запустилась: ' + (errLines(cam) || 'нет ответа'));
      cam = null;
    }
    if (cam) cam.hasMic = !!mic;
    await Promise.race([main.exitP, sleep(2000)]);
    if (main.exited) { tracks.forEach(t => t.feeder.finish()); throw new Error(errLines(main) || 'ffmpeg завершился сразу после старта'); }
    return { ok: true, main, cam, servers, goAt };
  } catch (e) { await cleanup(); return { ok: false, err: String(e.message || e) }; }
}

async function startRecording() {
  if (ST.rec.state !== 'idle' || shuttingDown) return;
  const s = ST.settings; ST.rec = Object.assign({}, ST.rec, { state: 'starting', error: '', files: [], stats: null, audio: {} }); emitState();
  try {
    if (ST.setup.running) throw new Error('Дождитесь завершения настройки MaxRec');
    if (!ST.ready.helper || !ST.caps.probed) throw new Error('Аудио-модуль или кодеры ещё не готовы');
    if (!ST.ready.ffmpeg) throw new Error('FFmpeg не установлен — откройте «Система» и нажмите «Установить»');
    const mon = ST.dev.monitors.find(m => m.idx === s.video.monitor) || ST.dev.monitors[0] || { idx: 0, w: 1920, h: 1080 };
    ensureTracks(s);
    const geo = core.geometry(s, mon), session = mkSession(s);
    FLOG = fs.createWriteStream(path.join(DATA, 'logs', 'ffmpeg-last.log'));
    FLOG.on('error', e => log('ffmpeg log error', e));
    FLOG.write('MaxRec ' + VERSION + ' | ' + ST.caps.version + '\n');
    const tracks = s.audio.tracks.filter(core.trackActive).map(t => TRACKS[t.id]).filter(Boolean);
    for (let i = 0; i < 25 && tracks.some(t => t.status === 'init' || t.status === 'starting'); i++) await sleep(100);
    let res = null, lastErr = '';
    for (const at of buildAttempts(s, geo)) {
      res = await tryStart(s, session, at, tracks, geo, mon);
      if (res.ok) { res.at = at; break; } lastErr = res.err; log('attempt failed', at, res.err); res = null;
    }
    if (!res) throw new Error(lastErr || 'Не удалось запустить запись');
    REC = { settings: s, session, tracks, main: res.main, cam: res.cam, servers: res.servers, at: res.at, stopping: false, tick: null };
    const note = res.at.enc === 'cpu' && resolveEncoder(s.video.encoder, s.video.codec).enc !== 'cpu' ? ' — аппаратный кодер не запустился, пишу на процессоре' : '';
    ST.rec = Object.assign({}, ST.rec, { state: 'recording', startedAt: res.goAt, info: encLabel(res.at) + note });
    if (note) toast('warn', 'Аппаратный кодер не запустился, запись идёт на процессоре (x264). Подробности — в «Система → Лог».');
    REC.tick = setInterval(() => {
      let size = 0; try { size = fs.statSync(session.main).size; } catch (e) {}
      const st = REC.main.stats || {}; const au = {}; tracks.forEach(t => { au[t.id] = Object.assign({}, t.feeder.stats); });
      ST.rec.stats = { fps: st.fps || 0, drop: st.drop || 0, speed: st.speed || 0, size }; ST.rec.audio = au; emitState();
    }, 1000);
    REC.main.exitP.then(code => { if (REC && !REC.stopping) { log('ffmpeg died during recording', code); toast('error', 'Запись неожиданно остановилась: ' + errLines(REC.main)); finalize(true); } });
    log('RECORDING', session.main); emitState();
  } catch (e) {
    if (FLOG) { FLOG.end(); FLOG = null; }
    log('start failed', e); ST.rec = Object.assign({}, ST.rec, { state: 'idle', error: String(e.message || e) });
    toast('error', ST.rec.error); if (!ST.monitoring) stopAllTracks(); emitState();
  }
}
const encLabel = at => ({ nvenc: 'NVIDIA NVENC', amf: 'AMD AMF', qsv: 'Intel QSV', cpu: 'Процессор' }[at.enc]) + ' · ' + ({ h264: 'H.264', hevc: 'HEVC', av1: 'AV1' }[at.codec]);

function finalize(crashed) {
  const R = REC;
  if (!R) return Promise.resolve();
  if (R.stopPromise) return R.stopPromise;
  R.stopping = true;
  R.stopPromise = finishRecording(R, crashed).catch(e => {
    log('finish failed', e);
    ST.rec.error = String(e.message || e);
    toast('error', ST.rec.error);
  }).finally(() => {
    REC = null;
    if (FLOG) { FLOG.end(); FLOG = null; }
    ST.rec.state = 'idle'; ST.rec.startedAt = 0;
    if (ST.monitoring && !shuttingDown) ensureTracks(); else stopAllTracks();
    emitState();
  });
  return R.stopPromise;
}
async function finishRecording(R, crashed) {
  clearInterval(R.tick);
  ST.rec.state = 'stopping'; emitState();
  // сначала команда «q» (видео и звук заканчиваются в один момент), сразу за ней — финальный сброс звука
  [R.main, R.cam].forEach(o => { if (o && !o.exited) { try { o.p.stdin.write('q'); } catch (e) {} } });
  R.tracks.forEach(t => t.feeder.finish());
  const waitExit = async o => { if (!o || o.exited) return; const r = await Promise.race([o.exitP, sleep(15000).then(() => 'timeout')]); if (r === 'timeout') killTree(o.p); };
  await Promise.all([waitExit(R.main), waitExit(R.cam)]);
  R.servers.forEach(x => { try { x.srv.close(); } catch (e) {} });
  const s = R.settings, files = [], exists = p => { try { return fs.statSync(p).size > 0; } catch (e) { return false; } };
  let main = R.session.main;
  if (exists(main) && s.output.container === 'mp4') main = await remux(main, s.output.keepMkv, 'Screen', R.tracks.map(t => t.cfg.name), R.at.codec === 'hevc', s.audio.codec === 'aac' ? 0 : s.audio.bitrate);
  const addF = (kind, p) => { if (exists(p)) files.push({ kind, path: p, size: fs.statSync(p).size }); };
  addF('video', main);
  if (R.cam && exists(R.session.cam)) { let c = R.session.cam; if (s.output.container === 'mp4') c = await remux(c, s.output.keepMkv, 'Webcam', R.cam.hasMic ? ['Mic'] : []); addF('webcam', c); }
  if (s.audio.wav) R.tracks.forEach((t, i) => { addF('audio', R.session.wav(i, t.cfg.name, s.audio.wavFormat === 'flac' ? 'flac' : 'wav')); });
  ST.rec = Object.assign({}, ST.rec, { files, error: files.length ? '' : 'Файл записи не создан — смотрите лог' });
  if (files.length && !crashed) toast('ok', 'Запись сохранена');
  if (files.length && s.output.openAfter) openPath(path.dirname(files[0].path), false);
  emitState();
}
async function remux(src, keep, vName, aNames, hevc, aacBitrate) {
  const dst = src.replace(/\.mkv$/i, '.mp4'), meta = ['-metadata:s:v:0', 'handler_name=' + vName].concat(hevc ? ['-tag:v:0', 'hvc1'] : []);
  (aNames || []).forEach((n, i) => meta.push('-metadata:s:a:' + i, 'handler_name=' + n, '-metadata:s:a:' + i, 'title=' + n));
  const r = await run(FFMPEG, ['-hide_banner', '-y', '-loglevel', 'error', '-i', src, '-map', '0', '-c', 'copy'].concat(meta, aacBitrate && aNames.length ? ['-c:a', 'aac', '-b:a', Math.min(aacBitrate, 320) + 'k'] : [], ['-movflags', '+faststart', dst]), { timeout: 600000 });
  if (r.code === 0 && fs.existsSync(dst)) { if (!keep) { try { fs.unlinkSync(src); } catch (e) {} } return dst; }
  try { fs.rmSync(dst, { force: true }); } catch (e) { log('remove incomplete MP4', e); }
  log('remux failed', r.err); toast('warn', 'Не удалось конвертировать в MP4 — оставил MKV'); return src;
}
const stopRecording = () => ST.rec.state === 'recording' ? finalize(false) : Promise.resolve();
const toggleRec = () => ST.rec.state === 'idle' ? startRecording() : stopRecording();

// ---------------- горячая клавиша ----------------
let HK = null;
function stopHotkey() { if (HK) { try { HK.stdin.end(); HK.kill(); } catch (e) {} HK = null; } }
function startHotkey() {
  stopHotkey(); ST.hotkey = { ok: false, err: '' }; if (!ST.ready.helper) return emitState();
  const h = ST.settings.hotkey, sp = helperSpawn(['hotkey', '--mods', String(h.mods), '--vk', String(h.vk)]); let p;
  try { p = cp.spawn(sp.cmd, sp.args, { windowsHide: true, stdio: ['pipe', 'pipe', 'pipe'] }); } catch (e) { return; }
  HK = p; p.stdin.on('error', () => {});
  p.stdout.on('data', d => { if (/HOTKEY/.test(d.toString())) toggleRec(); });
  p.stderr.on('data', d => { const t = d.toString(); if (/READY/.test(t)) ST.hotkey = { ok: true, err: '' }; else if (/ERR/.test(t)) ST.hotkey = { ok: false, err: 'Это сочетание занято другим приложением' }; emitState(); });
  p.on('error', () => {}); p.on('exit', () => { if (HK === p) HK = null; });
}

// ---------------- установка ----------------
async function runSetup() {
  if (ST.setup.running) return;
  ST.setup = { running: true, step: 'Подготовка…', pct: 1, error: '', needed: true }; emitState();
  try {
    let valid = false;
    if (fs.existsSync(FFMPEG)) { try { await validateFfmpeg(FFMPEG); valid = true; } catch (e) { log(e.message); } }
    if (!valid) { ST.ready.ffmpeg = false; await installFfmpeg(); }
    ST.ready.ffmpeg = fs.existsSync(FFMPEG);
    step('Собираю аудио-модуль…', 66); await ensureHelper(); ST.ready.helper = true;
    await probeCaps(true);
    step('Ищу устройства…', 94); await discover();
    ST.setup = { running: false, step: 'Готово', pct: 100, error: '', needed: false };
  } catch (e) { log('setup error', e); ST.setup = { running: false, step: '', pct: ST.setup.pct, error: String(e.message || e), needed: true }; }
  startHotkey(); emitState();
}
async function boot() {
  ST.ready.ffmpeg = fs.existsSync(FFMPEG); ST.ready.helper = helperUpToDate();
  ST.setup.needed = !ST.ready.ffmpeg || !ST.ready.helper; emitState();
  if (ST.setup.needed) await runSetup();
  else {
    try { await probeCaps(false); await discover(); startHotkey(); }
    catch (e) { ST.setup.error = e.message; ST.setup.needed = true; log('boot failed', e); }
  }
  prewarmRoots();
  emitState();
}

// ---------------- HTTP ----------------
const MIME = { '.html': 'text/html; charset=utf-8', '.js': 'text/javascript; charset=utf-8', '.css': 'text/css; charset=utf-8', '.woff2': 'font/woff2', '.woff': 'font/woff', '.png': 'image/png', '.jpg': 'image/jpeg', '.svg': 'image/svg+xml', '.ico': 'image/x-icon' };
const send = (res, code, text, type) => { res.writeHead(code, { 'Content-Type': type || 'text/plain; charset=utf-8', 'Cache-Control': 'no-store' }); res.end(text); };
const json = (res, obj, code) => send(res, code || 200, JSON.stringify(obj), 'application/json; charset=utf-8');
function readBody(req) { return new Promise((resolve, reject) => { let b = ''; req.on('data', d => { b += d; if (b.length > 1e6) { req.destroy(); reject(new Error('too big')); } }); req.on('end', () => resolve(safeJson(b))); req.on('error', reject); }); }
function serveStatic(res, p) {
  const base = path.join(APP_DIR, 'ui'), f = path.normalize(path.join(base, p === '/' ? 'index.html' : p));
  const relative = path.relative(base, f);
  if (f.includes('\0')) return send(res, 400, 'bad path');
  if (relative === '..' || relative.startsWith('..' + path.sep) || path.isAbsolute(relative)) return send(res, 403, 'forbidden');
  fs.readFile(f, (e, b) => { if (e) return send(res, 404, 'not found'); res.writeHead(200, { 'Content-Type': MIME[path.extname(f).toLowerCase()] || 'application/octet-stream', 'Cache-Control': 'no-store' }); res.end(b); });
}
function openPath(p, select) {
  if (!IS_WIN) return log('open', p);
  try { cp.spawn('explorer.exe', select ? ['/select,', p] : [p], { detached: true, stdio: 'ignore' }).unref(); } catch (e) {}
}
async function snapshot(kind, body) {
  const out = path.join(DATA, 'snap-' + kind + '.jpg'); let args;
  const tail = ['-frames:v', '1', '-q:v', '4', out];
  if (kind === 'screen') {
    const idx = (ST.dev.monitors.find(m => m.idx === ST.settings.video.monitor) || { idx: 0 }).idx;
    const src = TEST ? 'testsrc2=size=1280x720:rate=5,scale=960:-2,format=yuvj420p' : `ddagrab=output_idx=${idx}:framerate=5,hwdownload,format=bgra,scale=960:-2,format=yuvj420p`;
    args = ['-hide_banner', '-y', '-loglevel', 'error', '-f', 'lavfi', '-i', src].concat(tail);
  } else {
    const w = core.sanitize({ webcam: { ...ST.settings.webcam, ...body.webcam } }, DEF).webcam;
    args = ['-hide_banner', '-y', '-loglevel', 'error'].concat(core.camInput(w, camTest()), ['-vf', 'scale=960:-2,format=yuvj420p'], tail);
  }
  try { fs.unlinkSync(out); } catch (e) {}
  let r = await run(FFMPEG, args, { timeout: 15000 });
  if (r.code !== 0 && kind === 'screen' && IS_WIN && !TEST && ST.settings.video.monitor === 0) {
    r = await run(FFMPEG, ['-hide_banner', '-y', '-loglevel', 'error', '-f', 'gdigrab', '-framerate', '5', '-i', 'desktop', '-vf', 'scale=960:-2', ...tail], { timeout: 15000 });
  }
  if (r.code !== 0 || !fs.existsSync(out)) throw new Error((r.err || 'не удалось получить кадр').trim().split('\n').slice(-2).join(' ').slice(0, 300));
  return { url: '/snap/' + kind + '.jpg?' + Date.now() };
}

async function api(req, res, u) {
  const p = u.pathname;
  if (p === '/api/ping') return json(res, { ok: true, name: NAME });
  if (p === '/api/state') return json(res, publicState());
  if (p === '/api/events') {
    res.writeHead(200, { 'Content-Type': 'text/event-stream', 'Cache-Control': 'no-store', Connection: 'keep-alive' });
    res.write('retry: 1500\n\n'); sse(res, 'state', publicState()); clients.add(res);
    const ka = setInterval(() => { try { res.write(': ka\n\n'); } catch (e) {} }, 15000);
    res.on('close', () => { clients.delete(res); clearInterval(ka); }); return;
  }
  const b = req.method === 'POST' ? await readBody(req) : {};
  if (!b || typeof b !== 'object' || Array.isArray(b)) return json(res, { error: 'Ожидается JSON-объект' }, 400);
  switch (p) {
    case '/api/settings': {
      const old = JSON.stringify([ST.settings.audio.tracks.map(t => [t.id, t.on, t.type, t.exe, t.device]), ST.settings.hotkey]);
      ST.settings = core.sanitize(core.deepMerge(ST.settings, b.patch || {}), DEF); saveSettings();
      const now = JSON.stringify([ST.settings.audio.tracks.map(t => [t.id, t.on, t.type, t.exe, t.device]), ST.settings.hotkey]);
      if (old !== now) { prewarmRoots(); if (ST.monitoring && ST.rec.state === 'idle') ensureTracks(); if (JSON.stringify(b.patch || {}).includes('hotkey')) startHotkey(); }
      emitState(); return json(res, { ok: true });
    }
    case '/api/rec': if (b.action === 'start') startRecording(); else if (b.action === 'stop') stopRecording(); else toggleRec(); return json(res, { ok: true });
    case '/api/monitor': setMonitor(b.on); return json(res, { ok: true });
    case '/api/setup':
      if (ST.rec.state !== 'idle' || ST.setup.running) return json(res, { error: 'Дождитесь завершения записи или настройки' }, 409);
      if (b.action === 'local') { try { await useLocalFfmpeg(b.path); } catch (e) { return json(res, { error: e.message }, 400); } }
      if (b.action === 'local') ST.caps.probed = false;
      if (b.action === 'reprobe') {
        ST.setup.running = true;
        try { await probeCaps(true); await discover(); return json(res, { ok: true }); }
        finally { ST.setup.running = false; emitState(); }
      }
      runSetup(); return json(res, { ok: true });
    case '/api/refresh': await discover(); return json(res, { ok: true });
    case '/api/apps': return json(res, { apps: await listApps() });
    case '/api/cam/options': return json(res, { options: await camOptions(String(b.device || '')) });
    case '/api/cam/dialog': if (IS_WIN && b.device) cp.spawn(FFMPEG, ['-hide_banner', '-f', 'dshow', '-show_video_device_dialog', 'true', '-i', 'video=' + b.device], { windowsHide: false, stdio: 'ignore' }).unref(); return json(res, { ok: true });
    case '/api/snapshot': try { return json(res, await snapshot(b.kind === 'cam' ? 'cam' : 'screen', b)); } catch (e) { return json(res, { error: e.message }, 400); }
    case '/api/pick-folder': {
      if (!IS_WIN) return json(res, { path: '' });
      const q = String(b.path || '').replace(/'/g, "''");
      const r = await ps(`Add-Type -AssemblyName System.Windows.Forms; $f = New-Object System.Windows.Forms.FolderBrowserDialog; $f.SelectedPath = '${q}'; $t = New-Object System.Windows.Forms.Form; $t.TopMost = $true; if ($f.ShowDialog($t) -eq 'OK') { $f.SelectedPath }`, 600000);
      return json(res, { path: r.out.trim() });
    }
    case '/api/open': {
      if (b.what === 'logs') openPath(path.join(DATA, 'logs'), false); else if (b.what === 'file' && b.path) openPath(String(b.path), true); else openPath(ST.settings.output.folder, false);
      return json(res, { ok: true });
    }
    case '/api/quit': json(res, { ok: true }); setTimeout(() => shutdown(), 100); return;
  }
  json(res, { error: 'unknown' }, 404);
}
async function handler(req, res) {
  let u; try { u = new URL(req.url, 'http://x'); } catch (e) { return send(res, 400, 'bad URL'); }
  if (!/^(127\.0\.0\.1|localhost)(:\d+)?$/.test(req.headers.host || '')) return send(res, 403, 'bad host');
  if (u.pathname.startsWith('/api/')) {
    const expected = ['/api/ping', '/api/state', '/api/events', '/api/apps'].includes(u.pathname) ? 'GET' : 'POST';
    if (req.method !== expected) { res.setHeader('Allow', expected); return json(res, { error: 'method not allowed' }, 405); }
    if (expected === 'POST' && req.headers['x-maxrec'] !== '1') return send(res, 403, 'forbidden');
    try { return await api(req, res, u); } catch (e) { log('api error', u.pathname, e); return json(res, { error: String(e.message || e) }, 500); }
  }
  if (u.pathname.startsWith('/snap/')) { const f = path.join(DATA, path.basename(u.pathname).replace(/^/, 'snap-')); return fs.readFile(f, (e, d) => e ? send(res, 404, 'no') : (res.writeHead(200, { 'Content-Type': 'image/jpeg', 'Cache-Control': 'no-store' }), res.end(d))); }
  let p; try { p = decodeURIComponent(u.pathname); } catch (e) { return send(res, 400, 'bad'); }
  serveStatic(res, p);
}

// ---------------- запуск окна, единственный экземпляр, выход ----------------
function findBrowser() {
  const pf = process.env.ProgramFiles || 'C:\\Program Files', pf86 = process.env['ProgramFiles(x86)'] || 'C:\\Program Files (x86)', la = process.env.LOCALAPPDATA || '';
  return [path.join(pf86, 'Microsoft', 'Edge', 'Application', 'msedge.exe'), path.join(pf, 'Microsoft', 'Edge', 'Application', 'msedge.exe'),
    path.join(pf, 'Google', 'Chrome', 'Application', 'chrome.exe'), path.join(pf86, 'Google', 'Chrome', 'Application', 'chrome.exe'), path.join(la, 'Google', 'Chrome', 'Application', 'chrome.exe')].find(x => fs.existsSync(x)) || '';
}
function openUI(port) {
  if (process.env.MAXREC_NO_UI) return;
  const url = 'http://127.0.0.1:' + port + '/', b = findBrowser();
  try {
    if (b) cp.spawn(b, ['--app=' + url, '--user-data-dir=' + path.join(DATA, 'profile'), '--window-size=1240,820', '--no-first-run', '--no-default-browser-check', '--disable-features=Translate'], { detached: true, stdio: 'ignore' }).unref();
    else cp.spawn('cmd', ['/c', 'start', '', url], { detached: true, stdio: 'ignore', windowsHide: true }).unref();
  } catch (e) { log('openUI', e); }
}
const INST = path.join(DATA, 'instance.json');
function existingInstance() {
  const j = safeJson((() => { try { return fs.readFileSync(INST, 'utf8'); } catch (e) { return ''; } })()); if (!j || !j.port) return Promise.resolve(null);
  return new Promise(res => {
    const r = http.get({ host: '127.0.0.1', port: j.port, path: '/api/ping', timeout: 900 }, rs => { rs.resume(); res(rs.statusCode === 200 ? j : null); });
    r.on('error', () => res(null)); r.on('timeout', () => { r.destroy(); res(null); });
  });
}
let shuttingDown = false;
function shutdown() {
  if (shuttingDown) return; shuttingDown = true; log('shutdown');
  const go = () => { stopAllTracks(); stopHotkey(); try { fs.unlinkSync(INST); } catch (e) {} process.exit(0); };
  const finish = async () => { while (ST.rec.state === 'starting') await sleep(100); if (REC) await finalize(false); go(); };
  return finish();
}
let lastSeen = Date.now();
setInterval(() => {
  if (clients.size) { lastSeen = Date.now(); return; }
  const grace = Date.now() - START < 45000 ? 45000 : 8000;
  if (Date.now() - lastSeen > grace && ST.rec.state === 'idle' && !ST.setup.running && !process.env.MAXREC_KEEP) shutdown();
}, 2000);

(async () => {
  const ex = await existingInstance();
  if (ex && !process.env.MAXREC_PORT) { openUI(ex.port); process.exit(0); }
  const server = http.createServer(handler);
  server.listen(Number(process.env.MAXREC_PORT) || 0, '127.0.0.1', () => {
    const port = server.address().port; fs.writeFileSync(INST, JSON.stringify({ port, pid: process.pid }));
    log('MaxRec ' + VERSION + ' на порту ' + port + (TEST ? ' [TEST]' : '')); openUI(port); boot();
  });
  server.on('error', e => { log('server error', e); process.exit(1); });
})();
