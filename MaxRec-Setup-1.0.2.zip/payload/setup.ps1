﻿param([string]$Src)
$ErrorActionPreference = 'Stop'
if (-not $Src) { $Src = $PSScriptRoot }
Add-Type -AssemblyName System.Windows.Forms
Add-Type -AssemblyName System.Drawing
Add-Type -AssemblyName System.IO.Compression.FileSystem
try { [Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12 } catch {}
[System.Windows.Forms.Application]::EnableVisualStyles()

$Root = Join-Path $env:LOCALAPPDATA 'Programs\MaxRec'
$NodeVersion = '22.23.5'
$NodeArchive = "node-v$NodeVersion-win-x64.zip"
$NodeHash = '4a191082e9706866830379d577d2cc8a50c776fcd9436a8d061b063ed0d9a0e3'
$NodeUrls = @("https://nodejs.org/dist/v$NodeVersion/$NodeArchive", "https://npmmirror.com/mirrors/node/v$NodeVersion/$NodeArchive")
$PowerShell = Join-Path $env:SystemRoot 'System32\WindowsPowerShell\v1.0\powershell.exe'
$Log = Join-Path $env:TEMP 'maxrec-setup.log'
function Log([string]$m) { try { Add-Content -Path $Log -Value ((Get-Date -Format 'HH:mm:ss') + ' ' + $m) } catch {} }

# ---------- окно установки ----------
$white = [System.Drawing.Color]::White; $black = [System.Drawing.Color]::Black
$grey = [System.Drawing.Color]::FromArgb(150, 150, 150); $dark = [System.Drawing.Color]::FromArgb(55, 55, 55)
$form = New-Object System.Windows.Forms.Form
$form.Text = 'MaxRec'; $form.FormBorderStyle = 'None'; $form.StartPosition = 'CenterScreen'
$form.BackColor = $black; $form.ClientSize = New-Object System.Drawing.Size(520, 290); $form.TopMost = $true
$form.Add_Paint({ param($s, $e) $e.Graphics.DrawRectangle([System.Drawing.Pens]::DimGray, 0, 0, ($s.ClientSize.Width - 1), ($s.ClientSize.Height - 1)) })
function NewLabel($text, $font, $color, $y, $h) {
  $l = New-Object System.Windows.Forms.Label
  $l.Text = $text; $l.Font = $font; $l.ForeColor = $color; $l.BackColor = $black; $l.TextAlign = 'MiddleCenter'
  $l.Size = New-Object System.Drawing.Size(520, $h); $l.Location = New-Object System.Drawing.Point(0, $y)
  return $l
}
$title = NewLabel 'MaxRec' (New-Object System.Drawing.Font('Segoe UI Light', 36)) $white 58 90
$status = NewLabel 'Подготовка…' (New-Object System.Drawing.Font('Segoe UI', 10)) $grey 165 28
$track = New-Object System.Windows.Forms.Panel
$track.BackColor = $dark; $track.Size = New-Object System.Drawing.Size(360, 2); $track.Location = New-Object System.Drawing.Point(80, 214)
$fill = New-Object System.Windows.Forms.Panel
$fill.BackColor = $white; $fill.Size = New-Object System.Drawing.Size(1, 2); $fill.Location = New-Object System.Drawing.Point(80, 214)
$form.Controls.Add($title); $form.Controls.Add($status); $form.Controls.Add($track); $form.Controls.Add($fill)
$fill.BringToFront()

function Pump { [System.Windows.Forms.Application]::DoEvents() }
function Step([string]$text, [int]$pct) {
  $status.Text = $text
  if ($pct -ge 0) { $fill.Width = [Math]::Max(1, [int](360 * $pct / 100)) }
  Pump
}
function Download-File([string]$url, [string]$dest, [int]$p0, [int]$p1, [string]$label) {
  $req = [System.Net.HttpWebRequest]::Create($url)
  $req.UserAgent = 'MaxRec-Setup'; $req.AllowAutoRedirect = $true; $req.Timeout = 30000; $req.ReadWriteTimeout = 30000
  $res = $req.GetResponse()
  try {
    $total = $res.ContentLength
    $in = $res.GetResponseStream()
    $out = [System.IO.File]::Create($dest)
    try {
      $buf = New-Object byte[] 65536
      $got = 0L; $last = 0
      while (($n = $in.Read($buf, 0, $buf.Length)) -gt 0) {
        $out.Write($buf, 0, $n); $got += $n
        if (([Environment]::TickCount - $last) -gt 120) {
          $last = [Environment]::TickCount
          if ($total -gt 0) {
            $pp = $p0 + [int](($p1 - $p0) * $got / $total)
            Step ($label + '  ' + [int]($got / 1MB) + ' из ' + [int]($total / 1MB) + ' МБ') $pp
          } else { Step ($label + '  ' + [int]($got / 1MB) + ' МБ') -1 }
        }
      }
    } finally { $out.Close(); $in.Close() }
  } finally { $res.Close() }
}
function New-Shortcut([string]$path) {
  $sh = New-Object -ComObject WScript.Shell
  $s = $sh.CreateShortcut($path)
  $s.TargetPath = $PowerShell
  $s.Arguments = ('-NoProfile -STA -WindowStyle Hidden -ExecutionPolicy Bypass -File "' + (Join-Path $Root 'launch.ps1') + '"')
  $s.WorkingDirectory = $Root
  $s.IconLocation = Join-Path $Root 'app\app.ico'
  $s.Description = 'MaxRec'
  $s.Save()
}

$form.Opacity = 0; $form.Show()
for ($i = 1; $i -le 12; $i++) { $form.Opacity = $i / 12; Pump; Start-Sleep -Milliseconds 18 }

try {
  Log ('start; src=' + $Src + '; root=' + $Root)
  $appSrc = Join-Path $Src 'app'
  $launcher = Join-Path $Src 'launch.ps1'
  if (-not (Test-Path -LiteralPath (Join-Path $appSrc 'server.js') -PathType Leaf) -or -not (Test-Path -LiteralPath $launcher -PathType Leaf)) {
    throw 'Распакуйте ZIP целиком: в установщике не найдены файлы MaxRec.'
  }
  if (-not [Environment]::Is64BitOperatingSystem -or ($env:PROCESSOR_ARCHITECTURE -ne 'AMD64' -and $env:PROCESSOR_ARCHITEW6432 -ne 'AMD64')) {
    throw 'Этот установщик предназначен для 64-разрядной Windows на процессоре x64.'
  }
  $stage = Join-Path $env:TEMP ('maxrec-setup-' + [Guid]::NewGuid().ToString('N'))
  New-Item -ItemType Directory -Path $stage | Out-Null
  $nodeExe = Join-Path $Root 'runtime\node.exe'
  $stageRuntime = $null
  $installed = $null
  if (Test-Path -LiteralPath $nodeExe -PathType Leaf) {
    try { $installed = & $nodeExe --version 2>$null; if ($LASTEXITCODE -ne 0) { $installed = $null } } catch {}
  }
  if ($installed -ne "v$NodeVersion") {
    $zip = Join-Path $stage $NodeArchive
    $ok = $false; $lastErr = ''
    foreach ($u in $NodeUrls) {
      try {
        Download-File $u $zip 6 72 'Загрузка среды выполнения'
        if ((Get-FileHash -LiteralPath $zip -Algorithm SHA256).Hash -ne $NodeHash) { throw 'Не совпала контрольная сумма Node.js.' }
        $ok = $true; break
      } catch { $lastErr = $_.Exception.Message; Log ('download failed: ' + $u + ' ' + $lastErr) }
    }
    if (-not $ok) { throw ('Не удалось скачать Node.js. (' + $lastErr + ')') }
    Step 'Распаковываю…' 74
    $tmp = Join-Path $stage 'runtime'
    [System.IO.Compression.ZipFile]::ExtractToDirectory($zip, $tmp)
    $stageRuntime = Join-Path $tmp "node-v$NodeVersion-win-x64"
    if (-not (Test-Path -LiteralPath (Join-Path $stageRuntime 'node.exe') -PathType Leaf)) { throw 'В архиве Node.js не найден node.exe.' }
  }

  Step 'Проверяю, закрыта ли старая версия…' 82
  if (Test-Path -LiteralPath $nodeExe -PathType Leaf) {
    $running = @(Get-Process -Name node -ErrorAction SilentlyContinue | Where-Object { $_.Path -eq $nodeExe })
    if ($running.Count -gt 0) {
      throw 'Закройте MaxRec через «Система → Выйти из MaxRec», затем запустите установщик снова.'
    }
  }
  Step 'Копирую файлы программы…' 85
  New-Item -ItemType Directory -Force -Path $Root | Out-Null
  if ($stageRuntime) {
    $rt = Join-Path $Root 'runtime'
    New-Item -ItemType Directory -Force -Path $rt | Out-Null
    Copy-Item -LiteralPath (Join-Path $stageRuntime 'LICENSE') -Destination $rt -Force
    Copy-Item -LiteralPath (Join-Path $stageRuntime 'node.exe') -Destination $nodeExe -Force
  }
  $appDst = Join-Path $Root 'app'
  New-Item -ItemType Directory -Force -Path $appDst | Out-Null
  # Сначала копируем содержимое, не удаляя рабочую версию до завершения загрузки.
  Get-ChildItem -LiteralPath $appSrc -Force | ForEach-Object { Copy-Item -LiteralPath $_.FullName -Destination $appDst -Recurse -Force }
  Copy-Item -LiteralPath $launcher -Destination (Join-Path $Root 'launch.ps1') -Force

  Step 'Создаю ярлыки…' 90
  New-Shortcut (Join-Path ([Environment]::GetFolderPath('Desktop')) 'MaxRec.lnk')
  New-Shortcut (Join-Path ([Environment]::GetFolderPath('Programs')) 'MaxRec.lnk')

  Step 'Регистрирую в списке программ…' 94
  $k = 'HKCU:\Software\Microsoft\Windows\CurrentVersion\Uninstall\MaxRec'
  New-Item -Path $k -Force | Out-Null
  $vals = @{
    DisplayName = 'MaxRec'; DisplayVersion = '1.0.2'; Publisher = 'MaxRec'; InstallLocation = $Root
    DisplayIcon = (Join-Path $Root 'app\app.ico')
    UninstallString = ('"' + $PowerShell + '" -NoProfile -ExecutionPolicy Bypass -File "' + (Join-Path $Root 'app\uninstall.ps1') + '"')
  }
  foreach ($name in $vals.Keys) { Set-ItemProperty -Path $k -Name $name -Value $vals[$name] }

  Step 'Запускаю MaxRec…' 98
  Start-Process -FilePath $PowerShell -ArgumentList ('-NoProfile -STA -WindowStyle Hidden -ExecutionPolicy Bypass -File "' + (Join-Path $Root 'launch.ps1') + '"') -WorkingDirectory $Root -WindowStyle Hidden
  Step 'Готово' 100
  Start-Sleep -Milliseconds 900
  Log 'done'
}
catch {
  $msg = $_.Exception.Message
  Log ('ERROR: ' + $msg)
  $form.TopMost = $false
  $failed = $true
  [System.Windows.Forms.MessageBox]::Show(('Не удалось установить MaxRec:' + "`n`n" + $msg + "`n`n" + 'Журнал: ' + $Log), 'MaxRec', 'OK', 'Error') | Out-Null
}
finally {
  try { for ($i = 11; $i -ge 0; $i--) { $form.Opacity = $i / 12; Pump; Start-Sleep -Milliseconds 15 } } catch {}
  $form.Close()
  if ($stage) { Remove-Item -LiteralPath $stage -Recurse -Force -ErrorAction SilentlyContinue }
}
if ($failed) { exit 1 }
