﻿$ErrorActionPreference = 'Stop'
try {
  $node = Join-Path $PSScriptRoot 'runtime\node.exe'
  $entry = Join-Path $PSScriptRoot 'app\server.js'
  if (-not (Test-Path -LiteralPath $node -PathType Leaf) -or -not (Test-Path -LiteralPath $entry -PathType Leaf)) {
    throw 'Файлы MaxRec не найдены. Запустите Install.bat повторно.'
  }
  Start-Process -FilePath $node -ArgumentList ('"' + $entry + '"') -WorkingDirectory $PSScriptRoot -WindowStyle Hidden
} catch {
  Add-Type -AssemblyName System.Windows.Forms
  [System.Windows.Forms.MessageBox]::Show($_.Exception.Message, 'MaxRec', 'OK', 'Error') | Out-Null
  exit 1
}
